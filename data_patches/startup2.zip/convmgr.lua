ConversationData =
{
	{
		Actor1Type = "WT_TownPerson",
		Actor1State = "NONE",
		Actor2Type = "WT_TownPerson",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
					}
				}
			},
			{
				Name = "LP_TO_LP_HI",
				Data =
				{
					Actor = 1,
					Audio = "male_npc_chatter",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
					}
				}
			},
			{
				Name = "MAJOR_SCARED",
				Data =
				{
					Actor = 1,
					Audio = "npc_run_repulsed",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "hysterical_laughter",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
			{
				Name = "MINOR_SCARED",
				Data =
				{
					Actor = 1,
					Audio = "npc_scared_minor",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "npc_scated_minor_response",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
			{
				Name = "MAJOR_PUZZLED",
				Data =
				{
					Actor = 1,
					Audio = "npc_puzzled_major",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "npc_puzzled_major_response",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
			{
				Name = "MINOR_PUZZLED",
				Data =
				{
					Actor = 1,
					Audio = "npc_puzzled_minor",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "npc_puzzled_minor_response",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
			{
				Name = "MAJOR_CUTE",
				Data =
				{
					Actor = 1,
					Audio = "npc_infatuated_major",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "npc_infatuated_major_response",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
			{
				Name = "MINOR_CUTE",
				Data =
				{
					Actor = 1,
					Audio = "npc_infatuated_minor",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "npc_infatuated_minor_response",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
			{
				Name = "MAJOR_REPULSED",
				Data =
				{
					Actor = 1,
					Audio = "npc_run_repulsed",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "npc_repulsed_major_response",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
			{
				Name = "MINOR_REPULSED",
				Data =
				{
					Actor = 1,
					Audio = "npc_repulsed_minor",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "npc_repulsed_minor_response",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
			{
				Name = "MAJOR_FUNNY",
				Data =
				{
					Actor = 1,
					Audio = "npc_hysterical_laughter",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "npc_hysterical_laughter_response",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
			{
				Name = "MINOR_FUNNY",
				Data =
				{
					Actor = 1,
					Audio = "npc_run_repulsed",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "hysterical_laughter",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
		}
	},
	{
		Actor1Type = "AV_Buzz",
		Actor1State = "NONE",
		Actor2Type = "AV_Woody",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "buzz_woody_comment",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "woody_buzz_comment",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
		}
	},
	{
		Actor1Type = "AV_Jessie",
		Actor1State = "NONE",
		Actor2Type = "AV_Woody",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "jessie_woody_comment",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "woody_generic_response",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
		}
	},
	{
		Actor1Type = "AV_Buzz",
		Actor1State = "NONE",
		Actor2Type = "AV_Jessie",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "buzz_jessie_comment",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "jessie_comment_buzz1",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
		}
	},
	{
		Actor1Type = "AV_Woody",
		Actor1State = "NONE",
		Actor2Type = "AV_Jessie",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "woody_jessie_comment",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "jessie_comment_woody2",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
		}
	},
	{
		Actor1Type = "AV_Woody",
		Actor1State = "NONE",
		Actor2Type = "AV_Buzz",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "woody_buzz_comment",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "buzz_woody_comment",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
		}
	},
	{
		Actor1Type = "AV_Jessie",
		Actor1State = "NONE",
		Actor2Type = "AV_Buzz",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "jessie_woody_comment",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "woody_generic_response",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
		}
	},
	{
		Actor1Type = "WT_TownPerson",
		Actor1State = "NONE",
		Actor2Type = "AV_Buzz",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "npc_hi_buzz",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "buzz_npc_comment",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
		}
	},
	{
		Actor1Type = "WT_TownPerson",
		Actor1State = "NONE",
		Actor2Type = "AV_Woody",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "npc_hi_woody",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "woody_npc_comment",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
		}
	},
	{
		Actor1Type = "WT_TownPerson",
		Actor1State = "NONE",
		Actor2Type = "AV_Jessie",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "npc_hi_jessie",
				    Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
						{
							Actor = 2,
							Audio = "jessie_town_comment",
							Advance = true,
							Text = "",
							ExtraData = "",
							Response =
							{
							}
						},
					}
				}
			},
		}
	},
	{
		Actor1Type = "AV_AvatarAny",
		Actor1State = "NONE",
		Actor2Type = "AV_AvatarAny",
		Actor2State = "NONE",
		Conversations =
		{
			{
				Name = "Default",
				Data =
				{
					Actor = 1,
					Audio = "",
					Advance = true,
					Text = "",
					ExtraData = "",
					Response =
					{
					}
				}
			},
			{
				Name = "Player0Dialog",
				Data =
				{
					Actor = 2,
					Audio = "",
					Advance = false,
					Text = "",
					ExtraData = "",
					Response =
					{
					}
				}
			},
			{
				Name = "Player1Dialog",
				Data =
				{
					Actor = 2,
					Audio = "",
					Advance = false,
					Text = "",
					ExtraData = "",
					Response =
					{
					}
				}
			},
		},
	},
}
