--*************************************************
--
-- THIS IS A GENERATED FILE. DO NOT HAND EDIT IT.
--
--*************************************************

Data =
{
	Version = 0.0,
	Package = 'Toybox',
	Sets =
	{
		-- Engine Masks/Filters
		{
			set = 'ActorState',
			properties =
			{
			},
			count = 3,
			masks =
			{
				{	mask='CTF_BlueFlag', 	UID=3743 },
				{	mask='CTF_RedFlag', 	UID=3742 },
				{	mask='StinkPlantStinky', 	UID=3322 },
			},
		},
		{
			set = 'ActorType',
			properties =
			{
			},
			count = 69,
			masks =
			{
				{	mask='RR_Animal', 	UID=3159 },
				{	mask='RR_Arch', 	UID=2775 },
				{	mask='RR_BasicBlock', 	UID=118 },
				{	mask='RR_BeachBall', 	UID=1967 },
				{	mask='RR_BlipBlock', 	UID=3553 },
				{	mask='RR_BoostPad', 	UID=3164 },
				{	mask='RR_BowlingBall', 	UID=1968 },
				{	mask='RR_ConveyorBelt', 	UID=3168 },
				{	mask='RR_DirectionCamera', 	UID=267 },
				{	mask='RR_Elevator', 	UID=3207 },
				{	mask='RR_EnemyBeacon', 	UID=312 },
				{	mask='RR_Expendable', 	UID=1965 },
				{	mask='RR_ExplodingBlock', 	UID=158 },
				{	mask='RR_Fan', 	UID=3167 },
				{	mask='RR_FireHoop', 	UID=1956 },
				{	mask='RR_FireHoopSpinning', 	UID=1975 },
				{	mask='RR_Flipper', 	UID=3161 },
				{	mask='RR_Goal', 	UID=2773 },
				{	mask='RR_Invisinator', 	UID=122 },
				{	mask='RR_JetBarrel', 	UID=3163 },
				{	mask='RR_LaunchRamp', 	UID=3160 },
				{	mask='RR_LogicToy', 	UID=1966 },
				{	mask='RR_MovingBlock', 	UID=1976 },
				{	mask='RR_Pendulum', 	UID=3165 },
				{	mask='RR_PhysicsBlock', 	UID=1954 },
				{	mask='RR_PhysicsReset', 	UID=1960 },
				{	mask='RR_Population', 	UID=1978 },
				{	mask='RR_SkyDomeToy', 	UID=1955 },
				{	mask='RR_Slingshot', 	UID=136 },
				{	mask='RR_SoccerBall', 	UID=18 },
				{	mask='RR_Spinner', 	UID=3162 },
				{	mask='RR_SplashPool', 	UID=3166 },
				{	mask='RR_StandardBall', 	UID=4171 },
				{	mask='RR_Stunt_Car', 	UID=28 },
				{	mask='RR_SwordInStone', 	UID=3773 },
				{	mask='RR_Terrain', 	UID=1958 },
				{	mask='RR_TopDownCamera', 	UID=1962 },
				{	mask='RR_Track', 	UID=1969 },
				{	mask='RR_Tripwire', 	UID=194 },
				{	mask='RR_Turret', 	UID=2772 },
				{	mask='SR_Cart_King', 	UID=3821 },
				{	mask='SR_Cart_Vanellope', 	UID=3822 },
				{	mask='TB_AutopiaCar', 	UID=3430 },
				{	mask='TB_Dragon', 	UID=2995 },
				{	mask='TB_Jupiter_Train', 	UID=3823 },
				{	mask='TB_PhysicsBlockExplosive', 	UID=2737 },
				{	mask='TB_PhysicsBlockGlassCube', 	UID=2735 },
				{	mask='TB_PhysicsBlockGlassHorizontal', 	UID=2744 },
				{	mask='TB_PhysicsBlockGlassVertical', 	UID=2746 },
				{	mask='TB_PhysicsBlockMetalCube', 	UID=2745 },
				{	mask='TB_PhysicsBlockMetalHorizontal', 	UID=2738 },
				{	mask='TB_PhysicsBlockMetalVertical', 	UID=2743 },
				{	mask='TB_PhysicsBlockScoreEgg', 	UID=2742 },
				{	mask='TB_PhysicsBlockWoodCube', 	UID=2741 },
				{	mask='TB_PhysicsBlockWoodHorizontal', 	UID=2736 },
				{	mask='TB_PhysicsBlockWoodVertical', 	UID=2739 },
				{	mask='WR_RALPH_CAR', 	UID=3820 },
			},
			filters = 
			{
				{	filter='DrivableCars', 	desc='RR_Stunt_Car|WR_RALPH_CAR|SR_Cart_King|SR_Cart_Vanellope|TB_Jupiter_Train|TB_AutopiaCar', 	UID=3340 },
				{	filter='RR_Any', 	desc='RR_BasicBlock', 	UID=2184 },
				{	filter='RR_Ball', 	desc='RR_BeachBall|RR_BowlingBall|RR_SoccerBall|RR_StandardBall', 	UID=306 },
				{	filter='RR_FireHoopToy', 	desc='RR_FireHoop|RR_FireHoopSpinning', 	UID=1961 },
				{	filter='RR_ScoringObject', 	desc='RR_BeachBall|RR_BowlingBall|RR_SoccerBall', 	UID=218 },
				{	filter='RR_Toy', 	desc='RR_BeachBall|RR_BowlingBall|RR_DirectionCamera|RR_EnemyBeacon|RR_ExplodingBlock|RR_FireHoop|RR_FireHoopSpinning|RR_Invisinator|RR_LogicToy|RR_Slingshot|RR_SoccerBall|RR_Tripwire|RR_Goal', 	UID=1957 },
				{	filter='RR_Usable_Toy', 	desc='RR_SkyDomeToy', 	UID=1970 },
				{	filter='TB_PhysicsBlock', 	desc='TB_PhysicsBlockExplosive|TB_PhysicsBlockScoreEgg|TB_PhysicsBlockGlassCube|TB_PhysicsBlockGlassHorizontal|TB_PhysicsBlockGlassVertical|TB_PhysicsBlockMetalCube|TB_PhysicsBlockMetalHorizontal|TB_PhysicsBlockMetalVertical|TB_PhysicsBlockWoodCube|TB_PhysicsBlockWoodHorizontal|TB_PhysicsBlockWoodVertical', 	UID=2740 },
				{	filter='TowEquippedVehicle', 	desc='TB_Jupiter_Train', 	UID=288 },
				{	filter='Vehicles', 	desc='TB_AutopiaCar|RR_Stunt_Car|WR_RALPH_CAR|SR_Cart_King|SR_Cart_Vanellope|TB_Jupiter_Train', 	UID=132 },
				{	filter='VehiclesCab', 	desc='TB_AutopiaCar|RR_Stunt_Car|WR_RALPH_CAR|SR_Cart_King|SR_Cart_Vanellope|TB_Jupiter_Train', 	UID=2082 },
			},
			metafilters = 
			{
				{	filter='RR_zAny', 	desc='RR_Ball|RR_Mount|RR_Toy|RR_Usable_Toy', 	UID=2137 },
			},
		},
	}
}
