local L0_0, L1_1, L2_2, L3_3, L4_4
L0_0 = {}
L1_1 = {}
L2_2 = {}
L3_3 = {}
L3_3.AllowUGC = true
L3_3.lock = "TBX_WORLD_INCWORLD"
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.SAVE_INVENTORY = true
L2_2.RumpusRoom_incworld = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_Islet_Jug"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L3_3.SAVE_INVENTORY = true
L3_3.PlaysetProperties = "Pirates"
L3_3.worldIsPlayset = true
L3_3._ShowInMenu_ = false
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_Islet_Jug_tunnel = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_FortStGrande"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L3_3.SAVE_INVENTORY = true
L3_3.PlaysetProperties = "Pirates"
L3_3.worldIsPlayset = true
L3_3._ShowInMenu_ = false
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_FortStGrande_tunnel = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.CombatTeamPerceptionEnabled = false
L3_3.AutoSaveEnabled = false
L2_2.ADV_TUT_Physics = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.DefaultAvatar2 = "MU_Sully"
L3_3.DefaultAvatar = "MU_Mike"
L3_3.AutoSaveEnabled = false
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.RequiredAvatar = "MU_Mike"
L3_3.CombatTeamPerceptionEnabled = false
L2_2.ADV_IGP_MU_Mike = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.CombatTeamPerceptionEnabled = false
L3_3.ZonePath = "Worlds/ADV_RAC_LapRace_A/ADV_RAC_LapRace_A"
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.ADV_LapRace_Start_Position = 4
L3_3.AutoSaveEnabled = false
L2_2.ADV_RAC_LapRace_C = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L3_3.RealmBlendOffset = -10
L3_3._ShowInMenu_ = false
L4_4 = {
  {
    Blocker = "Blocker_GVT_To_MainTown",
    Link = "TS_MainTown"
  },
  {
    Blocker = "Blocker_GVT_To_GooValley",
    Link = "TS_GooValley"
  }
}
L3_3.Portals = L4_4
L3_3.worldIsPlayset = true
L3_3.MasterZone = "TS_Master"
L3_3.PlaysetProperties = "ToyStoryInSpace"
L3_3.SAVE_INVENTORY = true
L2_2.TS_GooValleyTunnel = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.DefaultAvatar2 = "FRO_Elsa"
L3_3.DefaultAvatar = "FRO_Anna"
L3_3.AutoSaveEnabled = false
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.RequiredAvatar = "FRO_Anna"
L3_3.CombatTeamPerceptionEnabled = false
L2_2.ADV_IGP_GEN_Anna = L3_3
L3_3 = {}
L3_3.DefaultAvatar = "PIR_JackSparrow"
L3_3.PlaysetProperties = "Pirates"
L3_3.DefaultAvatar3 = "PIR_Barbossa"
L4_4 = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L3_3.Portals = L4_4
L3_3.DefaultAvatar2 = "PIR_DavyJones"
L3_3.MasterZone = "PC_OceanMaster"
L3_3.DefaultAvatar4 = "PIR_JackSparrow"
L3_3.worldIsPlayset = true
L3_3.inventoryFilter = "LVL_PIRATES"
L3_3._ShowInMenu_ = false
L3_3.SAVE_INVENTORY = true
L2_2.PC_Islet_Fort = L3_3
L3_3 = {}
L3_3.AllowUGC = true
L3_3.lock = "TBX_WORLD_BRIDGES"
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.SAVE_INVENTORY = true
L2_2.RumpusRoom_Bridges = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.DefaultAvatar2 = "AV_Buzz"
L3_3.DefaultAvatar = "AV_Jessie"
L3_3.AutoSaveEnabled = false
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.RequiredAvatar = "AV_Jessie"
L3_3.CombatTeamPerceptionEnabled = false
L2_2.ADV_IGP_TS_Jessie = L3_3
L3_3 = {}
L3_3.DefaultAvatar = "PIR_JackSparrow"
L3_3.PlaysetProperties = "Pirates"
L3_3.DefaultAvatar3 = "PIR_Barbossa"
L4_4 = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L3_3.Portals = L4_4
L3_3.DefaultAvatar2 = "PIR_DavyJones"
L3_3.MasterZone = "PC_OceanMaster"
L3_3.DefaultAvatar4 = "PIR_JackSparrow"
L3_3.worldIsPlayset = true
L3_3.inventoryFilter = "LVL_PIRATES"
L3_3._ShowInMenu_ = false
L3_3.SAVE_INVENTORY = true
L2_2.PC_DeadMansCove = L3_3
L3_3 = {}
L3_3.AllowUGC = true
L3_3.lock = "TBX_WORLD_BLANK"
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.SAVE_INVENTORY = true
L2_2.RumpusRoom_IOS_Start = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.DefaultAvatar2 = "FRO_Anna"
L3_3.DefaultAvatar = "FRO_Elsa"
L3_3.AutoSaveEnabled = false
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.RequiredAvatar = "FRO_Elsa"
L3_3.CombatTeamPerceptionEnabled = false
L2_2.ADV_IGP_GEN_IceQueen = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.DefaultAvatar2 = "LR_Tonto"
L3_3.DefaultAvatar = "LR_LoneRanger"
L3_3.AutoSaveEnabled = false
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.RequiredAvatar = "LR_LoneRanger"
L3_3.CombatTeamPerceptionEnabled = false
L2_2.ADV_IGP_LR_LoneRanger = L3_3
L3_3 = {}
L4_4 = {
  "TrafficCar(Green)",
  "TrafficCar(Yellow)",
  "TrafficCar(Diesel)"
}
L3_3.CarList0 = L4_4
L3_3.WolfpackQuarterback = true
L4_4 = {
  {
    {
      "TrafficCar(Green)"
    },
    {
      "Blockhead(INC_BusinessMan01)",
      "Blockhead(INC_BusinessWoman01)"
    }
  },
  {
    {
      "TrafficCar(Yellow)"
    },
    {
      "Blockhead(INC_BusinessMan02)",
      "Blockhead(INC_BusinessWoman02)"
    }
  },
  {
    {
      "TrafficCar(Orange)"
    },
    {
      "Blockhead(INC_BusinessMan03)",
      "Blockhead(INC_BusinessWoman03)"
    }
  },
  {
    {
      "TrafficCar(Diesel)",
      "TrafficCar(Forklift)"
    },
    {
      "Blockhead(INC_ConstructionWorker)"
    }
  },
  {
    {
      "TrafficCar(Firetruck)"
    },
    {
      "Blockhead(INC_Fireman)"
    }
  },
  {
    {
      "TrafficCar(Police)"
    },
    {"NONE"}
  },
  {
    {
      "TrafficCar(SuperHeavyPaddywagon)"
    },
    {"NONE"}
  }
}
L3_3.DriverList = L4_4
L4_4 = {}
L4_4.WarningZoneRealm = "EOW_IN"
L3_3.EdgeOfWorldQuarterback = L4_4
L3_3.ThrownCarsDoDamage = true
L3_3.SAVE_INVENTORY = true
L3_3.ZoneType = "Master"
L3_3.ScourgeQuarterback = true
L4_4 = {
  "NewspaperStand"
}
L3_3.CarList3 = L4_4
L4_4 = {
  {
    "RC_TOY_CAR_ORANGE",
    "TrafficCar(Orange)",
    ""
  },
  {
    "RC_TOY_CAR_AMBULANCE",
    "TrafficCar(Ambulance)",
    ""
  },
  {
    "RC_TOY_CAR_FORKLIFT",
    "TrafficCar(Forklift)",
    ""
  },
  {
    "RC_TOY_CAR_INC_ICECREAMTRUCK",
    "TrafficCar(IceCreamTruck)",
    ""
  },
  {
    "RC_TOY_CAR_INC_TRUCK_PURPLE",
    "TrafficCar(PurpleTruck)",
    ""
  },
  {
    "RC_TOY_CAR_INC_CARDIESEL_GREY",
    "TrafficCar(GreyDiesel)",
    ""
  },
  {
    "RC_TOY_CAR_INC_CARORANGE_PINK",
    "TrafficCar(OrangePink)",
    ""
  },
  {
    "RC_TOY_CAR_INC_SPORTSCAR_GREEN",
    "TrafficCar(GreenSportsCar)",
    ""
  },
  {
    "RC_TOY_CAR_INC_BUS",
    "TrafficCar(Bus)",
    ""
  }
}
L3_3.CatalogCarList = L4_4
L4_4 = {
  "Blockhead(INC_BusinessMan01)",
  "Blockhead(INC_BusinessMan02)",
  "Blockhead(INC_BusinessMan03)",
  "Blockhead(INC_BusinessWoman01)",
  "Blockhead(INC_BusinessWoman02)",
  "Blockhead(INC_BusinessWoman03)",
  "Blockhead(INC_GenericMan01)",
  "Blockhead(INC_GenericMan02)",
  "Blockhead(INC_Girl)",
  "Blockhead(INC_Boy)",
  "Blockhead(INC_ConstructionWorker)"
}
L3_3.PedestrianList0 = L4_4
L3_3.TrafficQuarterback = true
L4_4 = {
  "HotdogStand"
}
L3_3.CarList1 = L4_4
L4_4 = {
  "TrafficCar(Firetruck)",
  "TrafficCar(Police)"
}
L3_3.CarList2 = L4_4
L3_3.CarLaneWidth = 7
L3_3.CarsShouldHonk = true
L3_3.ParachuteAvailableOnLevel = true
L3_3.worldIsPlayset = true
L3_3.CarsNeedDrivers = true
L3_3.FloatingCars = false
L3_3.PlaysetProperties = "Incredibles"
L2_2.IN_City = L3_3
L3_3 = {}
L3_3.AllowUGC = true
L3_3.lock = "TBX_WORLD_ISLANDS"
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.SAVE_INVENTORY = true
L2_2.RumpusRoom_Islands = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L3_3._ShowInMenu_ = false
L4_4 = {
  {
    Blocker = "Blocker_FratRowToCampus",
    Link = "MU_Campus"
  },
  {
    Blocker = "Blocker_CampusToFratRow",
    Link = "MU_FratRow"
  }
}
L3_3.Portals = L4_4
L3_3.worldIsPlayset = true
L3_3.PlaysetProperties = "MonstersU"
L3_3.MasterZone = "MU_Master"
L3_3.SAVE_INVENTORY = true
L2_2.MU_Tunnel_Campus_FratRow = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L3_3._ShowInMenu_ = false
L4_4 = {
  {
    Blocker = "Blocker_FearTechToCampus",
    Link = "MU_Campus"
  },
  {
    Blocker = "Blocker_CampusToFearTech",
    Link = "MU_FearTech"
  }
}
L3_3.Portals = L4_4
L3_3.worldIsPlayset = true
L3_3.PlaysetProperties = "MonstersU"
L3_3.MasterZone = "MU_Master"
L3_3.SAVE_INVENTORY = true
L2_2.MU_Tunnel_Campus_FT = L3_3
L3_3 = {}
L3_3._ShowInMenu_ = false
L3_3.PlaysetProperties = "ToyStoryInSpace"
L3_3.DefaultAvatar3 = "AV_Jessie"
L3_3.RealmBlendOffset = -10
L3_3.DefaultAvatar2 = "AV_Woody"
L3_3.MasterZone = "TS_Master"
L4_4 = {
  {
    Link = "TS_GooValleyTunnel"
  }
}
L3_3.Portals = L4_4
L3_3.worldIsPlayset = true
L3_3.DefaultAvatar = "AV_Buzz"
L3_3.DefaultAvatar4 = "AV_Buzz"
L3_3.SAVE_INVENTORY = true
L2_2.TS_GooValley = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.CombatTeamPerceptionEnabled = false
L3_3.AutoSaveEnabled = false
L2_2.ADV_TUT_Logic_PT1 = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.CombatTeamPerceptionEnabled = false
L3_3.AutoSaveEnabled = false
L2_2.ADV_CBT_ProtectMonolithSmall = L3_3
L3_3 = {}
L3_3.AllowUGC = true
L3_3.lock = "TBX_WORLD_LR"
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.SAVE_INVENTORY = true
L2_2.RumpusRoom_LR = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.DefaultAvatar2 = "AV_McQueen"
L3_3.DefaultAvatar = "AV_Mater"
L3_3.AutoSaveEnabled = false
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.RequiredAvatar = "AV_Mater"
L3_3.CombatTeamPerceptionEnabled = false
L2_2.ADV_IGP_CARS_Mater = L3_3
L3_3 = {}
L4_4 = {
  {
    Link = "MU_Tunnel_Campus_Sewer"
  }
}
L3_3.Portals = L4_4
L3_3.IdleAnimEvent = "IDLE"
L3_3._ShowInMenu_ = false
L3_3.WalkAnimEvent = "MOVE"
L3_3.PlaysetProperties = "MonstersU"
L3_3.CarsShouldHonk = false
L3_3.TrafficQuarterback = true
L3_3.InventoryFilter = "LVL_MONSTERS"
L3_3.DefaultAvatar = "MU_Sully"
L3_3.DefaultAvatar2 = "MU_Mike"
L3_3.MasterZone = "MU_Master"
L3_3.CarsNeedDrivers = true
L3_3.worldIsPlayset = true
L3_3.ThrownCarsDoDamage = false
L3_3.FloatingCars = false
L3_3.SAVE_INVENTORY = true
L2_2.MU_Sewer = L3_3
L3_3 = {}
L3_3.DefaultAvatar = "PIR_JackSparrow"
L3_3.PlaysetProperties = "Pirates"
L3_3.DefaultAvatar3 = "PIR_Barbossa"
L4_4 = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L3_3.Portals = L4_4
L3_3.DefaultAvatar2 = "PIR_DavyJones"
L3_3.MasterZone = "PC_OceanMaster"
L3_3.DefaultAvatar4 = "PIR_JackSparrow"
L3_3.worldIsPlayset = true
L3_3.inventoryFilter = "LVL_PIRATES"
L3_3._ShowInMenu_ = false
L3_3.SAVE_INVENTORY = true
L2_2.PC_ShipwreckShoals = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.CombatTeamPerceptionEnabled = false
L3_3.AutoSaveEnabled = false
L2_2.ADV_TUT_Driving2 = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_Islet_Fort"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L3_3.SAVE_INVENTORY = true
L3_3.PlaysetProperties = "Pirates"
L3_3.worldIsPlayset = true
L3_3._ShowInMenu_ = false
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_Islet_Fort_tunnel = L3_3
L3_3 = {}
L3_3.UIPlaysetFilter = "Developer_Worlds"
L3_3.AutoSaveEnabled = false
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L2_2.RumpusRoom_HH = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.CombatTeamPerceptionEnabled = false
L3_3.ZonePath = "Worlds/ADV_RAC_LapRace_A/ADV_RAC_LapRace_A"
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.ADV_LapRace_Start_Position = 0
L3_3.AutoSaveEnabled = false
L2_2.ADV_RAC_LapRace_B = L3_3
L3_3 = {}
L3_3.AllowUGC = true
L3_3.lock = "TBX_WORLD_HILLS"
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.SAVE_INVENTORY = true
L2_2.RumpusRoom_Hills = L3_3
L3_3 = {}
L3_3.ZoneType = "Master"
L3_3.forceLoad = "Intro"
L3_3.DefaultAvatar = "INTRO_Spark"
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.TrafficQuarterback = true
L3_3.LoadingScreen = "LoadingScreen_Intro"
L3_3.IntroSpark = 0
L3_3.AutoSaveEnabled = false
L3_3.OceanSystemQuarterback = true
L3_3.displayAvatarInfoHud = false
L3_3.IntroQuarterback = true
L3_3.worldIsIntro = true
L2_2.Intro_Master = L3_3
L3_3 = {}
L3_3.AllowUGC = true
L3_3.lock = "TBX_WORLD_PIRATES"
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.SAVE_INVENTORY = true
L2_2.RumpusRoom_Pirates = L3_3
L3_3 = {}
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L2_2.RumpusRoom_Announce = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.CombatTeamPerceptionEnabled = false
L3_3.AutoSaveEnabled = false
L2_2.ADV_BLD_Xbow_Catapult = L3_3
L3_3 = {}
L3_3.AllowUGC = true
L3_3.lock = "TBX_WORLD_BLANK"
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.SAVE_INVENTORY = true
L2_2.RumpusRoom_Blank = L3_3
L3_3 = {}
L3_3.AllowUGC = true
L3_3.lock = "TBX_WORLD_TOYSTORY"
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.SAVE_INVENTORY = true
L2_2.RumpusRoom_ToyStory = L3_3
L3_3 = {}
L3_3.AllowUGC = true
L3_3.lock = "TBX_WORLD_FLAT"
L3_3.worldExtentMaxY = 512
L3_3.worldExtentCenterY = 512
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.SAVE_INVENTORY = true
L2_2.rumpusroom_flat = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L3_3.RealmBlendOffset = -10
L3_3._ShowInMenu_ = false
L4_4 = {
  {
    Blocker = "CSBlocker_MainTownSide",
    Link = "TS_MainTown"
  },
  {
    Blocker = "CSBlocker_CombatSimSide",
    Link = "TS_CombatSim"
  }
}
L3_3.Portals = L4_4
L3_3.worldIsPlayset = true
L3_3.MasterZone = "TS_Master"
L3_3.PlaysetProperties = "ToyStoryInSpace"
L3_3.SAVE_INVENTORY = true
L2_2.TS_CombatSimTunnel = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.CombatTeamPerceptionEnabled = false
L3_3.AutoSaveEnabled = false
L2_2.ADV_CBT_Sumo = L3_3
L3_3 = {}
L3_3.DefaultAvatar = "PIR_JackSparrow"
L4_4 = {
  "Blockhead(PIR_Townspeople_Bayou_Male)",
  "Blockhead(PIR_Townspeople_Bayou_Female)"
}
L3_3.PedestrianList1 = L4_4
L3_3.PlaysetProperties = "Pirates"
L3_3.RecycleInNearDistancePeds = 40
L4_4 = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L3_3.Portals = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L3_3.IdleAnimEvent = "IDLE"
L3_3.RecycleOutNearDistancePeds = 50
L3_3.WalkAnimEvent = "MOVE"
L4_4 = {}
L4_4.RespawnOnFoot = false
L4_4.WarningZoneRealm = "EOW_Pirates"
L3_3.EdgeOfWorldQuarterback = L4_4
L3_3.ThrownCarsDoDamage = false
L3_3.FloatingCars = false
L3_3.RecycleInFarDistancePeds = 60
L3_3.SAVE_INVENTORY = true
L3_3.ZoneType = "Master"
L3_3.CarsShouldHonk = false
L3_3._ShowInMenu_ = false
L3_3.RecycleOutFarDistancePeds = 70
L3_3.CarsNeedDrivers = false
L4_4 = {
  "Blockhead(PIR_Townspeople_BountyHunter)",
  "Blockhead(PIR_Townspeople_Cook)",
  "Blockhead(PIR_Townspeople_Fisherman)",
  "Blockhead(PIR_Townspeople_Generic1)",
  "Blockhead(PIR_Townspeople_Generic2)",
  "Blockhead(PIR_Townspeople_Generic3)",
  "Blockhead(PIR_Townspeople_Generic4)",
  "Blockhead(PIR_Townspeople_Generic5)",
  "Blockhead(PIR_Townspeople_GenericFemale1)",
  "Blockhead(PIR_Townspeople_GenericFemale2)",
  "Blockhead(PIR_Townspeople_GenericFemale3)",
  "Blockhead(PIR_Townspeople_GenericFemale4)",
  "Blockhead(PIR_Townspeople_GenericFemale5)",
  "Blockhead(PIR_Townspeople_Gunner)",
  "Blockhead(PIR_Townspeople_Musician)",
  "Blockhead(PIR_Townspeople_Navigator)",
  "Blockhead(PIR_Townspeople_Swabbie)"
}
L3_3.PedestrianList0 = L4_4
L3_3.TrafficQuarterback = true
L3_3.DefaultAvatar3 = "PIR_Barbossa"
L3_3.OceanSystemQuarterback = true
L3_3.DefaultAvatar2 = "PIR_DavyJones"
L3_3.worldExtentCenterY = 800
L3_3.AmbientShipsQuarterback = true
L3_3.worldIsPlayset = true
L3_3.ShipManagementQuarterback = true
L3_3.DockingSystemQuarterback = true
L3_3.DefaultAvatar4 = "PIR_JackSparrow"
L2_2.PC_OceanMaster = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_DeadMansCove"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L3_3.SAVE_INVENTORY = true
L3_3.PlaysetProperties = "Pirates"
L3_3.worldIsPlayset = true
L3_3._ShowInMenu_ = false
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_DeadMansCove_tunnel = L3_3
L3_3 = {}
L3_3._ShowInMenu_ = false
L3_3.PlaysetProperties = "Cars"
L3_3.DefaultAvatar3 = "AV_Cars_Finn"
L4_4 = {
  {
    Link = "CA_TunnelConnector"
  }
}
L3_3.Portals = L4_4
L3_3.DefaultAvatar2 = "AV_Mater"
L3_3.MasterZone = "CA_Master"
L3_3.SAVE_INVENTORY = true
L3_3.worldIsPlayset = true
L3_3.DefaultAvatar = "AV_McQueen"
L3_3.DefaultAvatar4 = "AV_Holly"
L3_3.splitScreenHorizontal = true
L2_2.CA_WillysButte = L3_3
L3_3 = {}
L3_3.IsAdventure = true
L3_3.DefaultAvatar2 = "NBC_JackSkellington"
L4_4 = "TAN_Rapunzel"
L3_3.DefaultAvatar = L4_4
L4_4 = false
L3_3.AutoSaveEnabled = L4_4
L3_3.PlaysetProperties = "RumpusRoom"
L4_4 = "TAN_Rapunzel"
L3_3.RequiredAvatar = L4_4
L4_4 = false
L3_3.CombatTeamPerceptionEnabled = L4_4
L2_2.ADV_IGP_GEN_Rapunzel = L3_3
L3_3 = "ADV_TUT_Building"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.CombatTeamPerceptionEnabled = false
L4_4.AutoSaveEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_INC_MrIncredible"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_ElastiGirl"
L4_4.DefaultAvatar = "AV_MrIncredible"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "AV_MrIncredible"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_RAC_OffRoad"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.CombatTeamPerceptionEnabled = false
L4_4.AutoSaveEnabled = false
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.IdleAnimEvent = "IDLE"
L3_3.DefaultAvatar = "MU_Sully"
L3_3.WalkAnimEvent = "MOVE"
L3_3.PlaysetProperties = "MonstersU"
L4_4 = false
L3_3.CarsShouldHonk = L4_4
L4_4 = true
L3_3.TrafficQuarterback = L4_4
L3_3.InventoryFilter = "LVL_MONSTERS"
L4_4 = {
  {
    Link = "MU_Tunnel_Campus_FT"
  },
  {
    Link = "MU_Tunnel_Campus_FratRow"
  },
  {
    Link = "MU_Tunnel_Campus_Sewer"
  }
}
L3_3.Portals = L4_4
L3_3.DefaultAvatar2 = "MU_Mike"
L3_3.MasterZone = "MU_Master"
L4_4 = true
L3_3.CarsNeedDrivers = L4_4
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3.ThrownCarsDoDamage = L4_4
L4_4 = false
L3_3.FloatingCars = L4_4
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L2_2.MU_Campus = L3_3
L3_3 = "ADV_IGP_PF_Phineas"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "PNF_Perry"
L4_4.DefaultAvatar = "PNF_Phineas"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "PNF_Phineas"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_INC_MrsIncredible"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_MrIncredible"
L4_4.DefaultAvatar = "AV_ElastiGirl"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "AV_ElastiGirl"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_MU_Sulley"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "MU_Mike"
L4_4.DefaultAvatar = "MU_Sully"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "MU_Sully"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L4_4 = {
  {
    Blocker = "Blocker_SewerToCampus",
    Link = "MU_Campus"
  },
  {
    Blocker = "Blocker_CampusToSewer",
    Link = "MU_Sewer"
  }
}
L3_3.Portals = L4_4
L4_4 = true
L3_3.worldIsPlayset = L4_4
L3_3.PlaysetProperties = "MonstersU"
L3_3.MasterZone = "MU_Master"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L2_2.MU_Tunnel_Campus_Sewer = L3_3
L3_3 = "_DefaultValues_"
L4_4 = {}
L4_4.yDeathPlaneOffset = -20
L4_4.DefaultAvatar = "AV_MrIncredible"
L4_4.playTalkCalloutSound = false
L4_4.worldExtentMaxY = 1024
L4_4.UID = 0
L4_4.FallbackAvatar = "AV_Sparkman"
L4_4.AutoSaveEnabled = true
L4_4.CatalogExcludeList = ""
L4_4.blockheadCustomizationFilter = ""
L4_4.worldExtentMaxZ = 2048
L4_4._ShowInMenu_ = false
L4_4.worldExtentCenterZ = 0
L4_4.worldIsIntro = false
L4_4.worldExtentMaxX = 2048
L4_4.worldExtentCenterX = 0
L4_4.DefaultAvatar3 = "AV_MrIncredible"
L4_4.worldExtentCenterY = 0
L4_4.DefaultAvatar2 = "AV_MrIncredible"
L4_4.LoadingScreen = "LoadingScreen_ToyBox"
L4_4.ShowDecorationsInCatalog = false
L4_4.worldIsPlayset = false
L4_4.displayAvatarInfoHud = true
L4_4.inventoryFilter = "LVL_RUMPUSROOM"
L4_4.DefaultAvatar4 = "AV_MrIncredible"
L2_2[L3_3] = L4_4
L3_3 = {}
L4_4 = "disableItemPropScreen"
L3_3[L4_4] = true
L3_3.DefaultAvatar = "AV_McQueen"
L4_4 = "playTalkCalloutSound"
L3_3[L4_4] = true
L3_3.PlaysetProperties = "Cars"
L4_4 = "TunnelBlockerLoadingCho"
L3_3[L4_4] = "UI_ZoneLoad"
L4_4 = false
L3_3.CarsNeedDrivers = L4_4
L4_4 = false
L3_3.ThrownCarsDoDamage = L4_4
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.ZoneType = "Master"
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L4_4 = {
  {
    "RC_TOY_TRAFFIC_TRUCK",
    "TrafficCar(Truck)",
    ""
  },
  {
    "RC_TOY_TRAFFIC_VAN",
    "TrafficCar(Van)",
    ""
  }
}
L3_3.CatalogCarList = L4_4
L4_4 = true
L3_3.TrafficQuarterback = L4_4
L3_3.DefaultAvatar3 = "AV_Cars_Finn"
L3_3.DefaultAvatar2 = "AV_Mater"
L4_4 = {
  "TrafficCar(Sedan)"
}
L3_3.CarList0 = L4_4
L4_4 = true
L3_3.CarsShouldHonk = L4_4
L4_4 = true
L3_3.worldIsPlayset = L4_4
L3_3.DefaultAvatar4 = "AV_Holly"
L4_4 = false
L3_3.FloatingCars = L4_4
L4_4 = true
L3_3.splitScreenHorizontal = L4_4
L2_2.CA_Master = L3_3
L3_3 = "RumpusRoom_Cars"
L4_4 = {}
L4_4.AllowUGC = true
L4_4.lock = "TBX_WORLD_CARS"
L4_4.worldExtentMaxY = 512
L4_4.worldExtentCenterY = 512
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_TS_Buzz"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_Woody"
L4_4.DefaultAvatar = "AV_Buzz"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "AV_Buzz"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.DefaultAvatar = "MU_Sully"
L3_3.PlaysetProperties = "MonstersU"
L4_4 = "PedestrianList9"
L3_3[L4_4] = {
  "Blockhead(FR_StudentMG_2)"
}
L4_4 = "MaxTrafficActorsSplitScreen"
L3_3[L4_4] = 20
L4_4 = "PedestrianList8"
L3_3[L4_4] = {
  "Blockhead(FR_StudentMG_PNK)"
}
L4_4 = true
L3_3.CarsNeedDrivers = L4_4
L4_4 = false
L3_3.ThrownCarsDoDamage = L4_4
L4_4 = 60
L3_3.RecycleInFarDistancePeds = L4_4
L3_3.ZoneType = "Master"
L3_3.forceLoad = "MU_Campus"
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L4_4 = "PedestrianJobCheckInterval"
L3_3[L4_4] = 8
L4_4 = "ShowDecorationsInCatalog"
L3_3[L4_4] = true
L4_4 = {
  "Blockhead(MU_Student_1)",
  "Blockhead(MU_Student_2)",
  "Blockhead(MU_Student_3)",
  "Blockhead(MU_Student_4)",
  "Blockhead(MU_Student_5)",
  "Blockhead(MU_Student_6)",
  "Blockhead(MU_Student_7)",
  "Blockhead(MU_Student_8)",
  "Blockhead(MU_Student_9)",
  "Blockhead(MU_Student_10)",
  "Blockhead(MU_Student_11)",
  "Blockhead(MU_Student_12)",
  "Blockhead(MU_Student_13)",
  "Blockhead(MU_Student_14)",
  "Blockhead(MU_Student_15)",
  "Blockhead(MU_Student_16)",
  "Blockhead(MU_Student_17)",
  "Blockhead(MU_Student_18)",
  "Blockhead(MU_Student_19)",
  "Blockhead(MU_Student_20)"
}
L3_3.PedestrianList0 = L4_4
L4_4 = "PedestrianList4"
L3_3[L4_4] = {
  "Blockhead(FR_StudentMG_1)"
}
L3_3.DefaultAvatar3 = "MU_Sully"
L4_4 = "PedestrianList10"
L3_3[L4_4] = {
  "Blockhead(FR_StudentMG_4)"
}
L3_3.WalkAnimEvent = "MOVE"
L4_4 = "PedestrianJobRadius"
L3_3[L4_4] = 18
L4_4 = "PedestrianList3"
L3_3[L4_4] = {
  "Blockhead(FR_StudentMG_ROR)"
}
L4_4 = "PedestrianList15"
L3_3[L4_4] = {
  "Blockhead(MU_StudentMG_5)"
}
L4_4 = "PedestrianList16"
L3_3[L4_4] = {
  "Blockhead(MU_GroundsKeeper)"
}
L4_4 = "PedestrianList14"
L3_3[L4_4] = {
  "Blockhead(MU_StudentMG_4)"
}
L4_4 = "PedestrianList13"
L3_3[L4_4] = {
  "Blockhead(MU_StudentMG_3)"
}
L4_4 = 40
L3_3.RecycleInNearDistancePeds = L4_4
L4_4 = "StealthQuarterback"
L3_3[L4_4] = true
L3_3.InventoryFilter = "LVL_MONSTERS"
L4_4 = "PedestrianList12"
L3_3[L4_4] = {
  "Blockhead(MU_StudentMG_2)"
}
L4_4 = 50
L3_3.RecycleOutNearDistancePeds = L4_4
L4_4 = "PedestrianList11"
L3_3[L4_4] = {
  "Blockhead(MU_StudentMG_1)"
}
L4_4 = "PedestrianList7"
L3_3[L4_4] = {
  "Blockhead(FR_StudentMG_3)"
}
L4_4 = "PedestrianList6"
L3_3[L4_4] = {
  "Blockhead(FR_StudentMG_EKO)"
}
L4_4 = "MaxTrafficActors"
L3_3[L4_4] = 25
L4_4 = "PedestrianList2"
L3_3[L4_4] = {
  "Blockhead(FR_StudentMG_JOX)"
}
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L4_4 = "PedestrianJobProbability"
L3_3[L4_4] = 1
L4_4 = {
  "Blockhead(FT_Student_1)",
  "Blockhead(FT_Student_2)",
  "Blockhead(FT_Student_3)",
  "Blockhead(FT_Student_4)",
  "Blockhead(FT_Student_5)",
  "Blockhead(FT_Student_6)",
  "Blockhead(FT_Student_7)",
  "Blockhead(FT_Student_8)",
  "Blockhead(FT_Student_9)",
  "Blockhead(FT_Student_10)",
  "Blockhead(FT_Student_11)",
  "Blockhead(FT_Student_12)",
  "Blockhead(FT_Student_13)",
  "Blockhead(FT_Student_14)",
  "Blockhead(FT_Student_15)",
  "Blockhead(FT_Student_16)",
  "Blockhead(FT_Student_17)",
  "Blockhead(FT_Student_18)",
  "Blockhead(FT_Student_19)",
  "Blockhead(FT_Student_20)"
}
L3_3.PedestrianList1 = L4_4
L3_3.IdleAnimEvent = "IDLE"
L4_4 = 70
L3_3.RecycleOutFarDistancePeds = L4_4
L4_4 = "PedestrianList5"
L3_3[L4_4] = {
  "Blockhead(FR_StudentMG_HSS)"
}
L4_4 = "PedestrianJobList"
L3_3[L4_4] = {
  {
    "MU_BH_Performer_LayOnBack_a_1",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_2",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_3",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_4",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_5",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_6",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_7",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_8",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_9",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_10",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_11",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_12",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_13",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_14",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_a_15",
    "Towns_SitSteps1",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_1",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_2",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_3",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_4",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_5",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_6",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_7",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_8",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_9",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_10",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_11",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_12",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_13",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_14",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnBack_b_15",
    "Towns_Idle3",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_1",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_2",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_3",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_4",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_5",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_6",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_7",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_8",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_9",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_10",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_11",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_12",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_13",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_14",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_LayOnStomach_15",
    "Towns_SitSteps2",
    60
  },
  {
    "MU_BH_Performer_Angry_a_1",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_2",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_3",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_4",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_5",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_6",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_7",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_8",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_9",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_10",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_11",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_12",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_13",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_14",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_a_15",
    "Towns_JobSits1",
    60
  },
  {
    "MU_BH_Performer_Angry_b_1",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_2",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_3",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_4",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_5",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_6",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_7",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_8",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_9",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_10",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_11",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_12",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_13",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_14",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_b_15",
    "Towns_Idle1",
    30
  },
  {
    "MU_BH_Performer_Angry_c_1",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_2",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_3",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_4",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_5",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_6",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_7",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_8",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_9",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_10",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_11",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_12",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_13",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_14",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_Angry_c_15",
    "Towns_JobSits1",
    10
  },
  {
    "MU_BH_Performer_SitOnSteps_1",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_2",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_3",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_4",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_5",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_6",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_7",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_8",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_9",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_10",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_11",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_12",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_13",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_14",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_15",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_16",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_17",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_18",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_19",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_20",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_21",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_22",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_23",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_24",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_SitOnSteps_25",
    "Towns_JobSits3",
    60
  },
  {
    "MU_BH_Performer_Dancing_1",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_2",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_3",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_4",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_5",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_6",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_7",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_8",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_9",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_10",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_11",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_12",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_13",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_14",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_Dancing_15",
    "Towns_LayDown1",
    45
  },
  {
    "MU_BH_Performer_SitFlatOnGround_1",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_2",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_3",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_4",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_5",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_6",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_7",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_8",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_9",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_10",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_11",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_12",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_13",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_14",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_15",
    "Towns_LayDown2",
    90
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_1",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_2",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_3",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_4",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_5",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_6",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_7",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_8",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_9",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_10",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_11",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_12",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_13",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_14",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Sway_15",
    "Towns_PopUp2",
    60
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_1",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_2",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_3",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_4",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_5",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_6",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_7",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_8",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_9",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_10",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_11",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_12",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_13",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_14",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_SitFlatOnGround_Admire_15",
    "Towns_FixWall",
    10
  },
  {
    "MU_BH_Performer_Excercise_1",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_2",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_3",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_4",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_5",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_6",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_7",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_8",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_9",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_10",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_11",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_12",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_13",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_14",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Excercise_15",
    "Towns_Idle2",
    60
  },
  {
    "MU_BH_Performer_Admire_1",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_2",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_3",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_4",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_5",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_6",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_7",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_8",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_9",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_10",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_11",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_12",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_13",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_14",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_Admire_15",
    "Towns_Idle4",
    10
  },
  {
    "MU_BH_Performer_FixWall_1",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_2",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_3",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_4",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_5",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_6",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_7",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_8",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_9",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_10",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_11",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_12",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_13",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_14",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_FixWall_15",
    "Towns_PopUp1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_1",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_2",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_3",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_4",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_5",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_6",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_7",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_8",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_9",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_10",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_11",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_12",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_13",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_14",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_a_15",
    "Towns_Job1",
    10
  },
  {
    "MU_BH_Performer_Groundskeeper_b_1",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_2",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_3",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_4",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_5",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_6",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_7",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_8",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_9",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_10",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_11",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_12",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_13",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_14",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_b_15",
    "Towns_Job2",
    20
  },
  {
    "MU_BH_Performer_Groundskeeper_c_1",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_2",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_3",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_4",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_5",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_6",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_7",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_8",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_9",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_10",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_11",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_12",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_13",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_14",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_Groundskeeper_c_15",
    "Towns_Job3",
    15
  },
  {
    "MU_BH_Performer_LookAtShoe_1",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_2",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_3",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_4",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_5",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_6",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_7",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_8",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_9",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_10",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_11",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_12",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_13",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_14",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_LookAtShoe_15",
    "Towns_Job4",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_1",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_2",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_3",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_4",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_5",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_6",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_7",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_8",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_9",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_10",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_11",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_12",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_13",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_14",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_a_15",
    "Towns_Job5",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_1",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_2",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_3",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_4",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_5",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_6",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_7",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_8",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_9",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_10",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_11",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_12",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_13",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_14",
    "Towns_Job6",
    10
  },
  {
    "MU_BH_Performer_PopUpFromBehind_b_15",
    "Towns_Job6",
    10
  }
}
L4_4 = true
L3_3.TrafficQuarterback = L4_4
L4_4 = false
L3_3.CarsShouldHonk = L4_4
L4_4 = "TunnelBlockerLoadingCho"
L3_3[L4_4] = "UI_ZoneLoad"
L3_3.DefaultAvatar2 = "MU_Mike"
L4_4 = "PhysicsTimeStep"
L3_3[L4_4] = 0.02
L4_4 = true
L3_3.ParachuteAvailableOnLevel = L4_4
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = "EnterAndExitBuildingsEnabled"
L3_3[L4_4] = true
L4_4 = false
L3_3.FloatingCars = L4_4
L3_3.DefaultAvatar4 = "MU_Mike"
L2_2.MU_Master = L3_3
L3_3 = "ADV_IGP_PF_Perry"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "PNF_Phineas"
L4_4.DefaultAvatar = "PNF_Perry"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "PNF_Perry"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.PlaysetProperties = "Pirates"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_Heidis_Secret_Ships = L3_3
L3_3 = "ADV_IGP_MU_Randall"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar = "MU_Randall"
L4_4.CarList0 = {
  "TrafficCar(Green)"
}
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.StealthQuarterback = true
L4_4.CarsNeedDrivers = true
L4_4.ThrownCarsDoDamage = false
L4_4.SAVE_INVENTORY = true
L4_4.PedestrianList0 = {"Monster05"}
L4_4.TrafficQuarterback = true
L4_4.RequiredAvatar = "MU_Randall"
L4_4.DefaultAvatar2 = "MU_Mike"
L4_4.AutoSaveEnabled = false
L4_4.CombatTeamPerceptionEnabled = false
L4_4.IdleAnimEvent = "IDLE"
L4_4.WalkAnimEvent = "MOVE"
L4_4.FloatingCars = false
L4_4.CarsShouldHonk = false
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.PlaysetProperties = "RumpusRoom"
L3_3.LoadingScreen = "LoadingScreen_Intro"
L4_4 = 0
L3_3.IntroSpark = L4_4
L3_3.MasterZone = "Intro_Master"
L4_4 = "TBX_WORLD_INTRO"
L3_3.lock = L4_4
L4_4 = "AsyncChoreographyList"
L3_3[L4_4] = {
  Intro_Castle = {
    {
      Name = "intro_dc_tree",
      Count = 1
    },
    {Name = "vaultb", Count = 1},
    {
      Name = "Intro_SparksLight",
      Count = 2
    },
    {
      Name = "Intro_Castle_Fireworks",
      Count = 1
    },
    {
      Name = "intro_reader",
      Count = 1
    }
  },
  Intro_Monsters = {
    {
      Name = "intro_avitarsparktransition",
      Count = 1
    },
    {Name = "mu_scarea", Count = 1},
    {
      Name = "Intro_MU_Lightpost",
      Count = 11
    },
    {
      Name = "intro_sparks",
      Count = 2
    }
  },
  Intro = {
    {
      Name = "Intro_SparkBurst",
      Count = 1
    },
    {
      Name = "intro_sparkimpacta",
      Count = 1
    },
    {
      Name = "Intro_LanternTrail",
      Count = 2
    },
    {
      Name = "intro_wallblockb",
      Count = 1
    },
    {
      Name = "intro_terraini1",
      Count = 1
    },
    {
      Name = "intro_terraina2",
      Count = 1
    },
    {
      Name = "intro_sparkinfluence",
      Count = 1
    },
    {
      Name = "intro_wallblockc",
      Count = 1
    },
    {
      Name = "intro_groundblockc",
      Count = 3
    },
    {
      Name = "intro_grndblockendcapb",
      Count = 1
    },
    {
      Name = "intro_groundblockb_end",
      Count = 1
    },
    {
      Name = "intro_skyreveal",
      Count = 1
    },
    {
      Name = "intro_gateopen",
      Count = 1
    },
    {
      Name = "intro_terrainh",
      Count = 1
    },
    {
      Name = "intro_groundblockb",
      Count = 1
    },
    {
      Name = "intro_terrainq3",
      Count = 2
    },
    {
      Name = "intro_terraino",
      Count = 1
    },
    {
      Name = "intro_terrainm1",
      Count = 1
    },
    {
      Name = "intro_vineb",
      Count = 1
    },
    {
      Name = "intro_stairs",
      Count = 1
    },
    {
      Name = "intro_wallblocka",
      Count = 1
    },
    {
      Name = "intro_grndblockcornera",
      Count = 1
    },
    {
      Name = "intro_grndblockcornerb",
      Count = 1
    },
    {
      Name = "intro_groundblocka",
      Count = 14
    },
    {
      Name = "intro_gatereveal",
      Count = 1
    },
    {
      Name = "intro_groundblocka_end",
      Count = 2
    },
    {
      Name = "intro_terrainp",
      Count = 1
    },
    {
      Name = "intro_treeasmall_dist",
      Count = 22
    },
    {
      Name = "intro_treea_dist",
      Count = 16
    },
    {
      Name = "intro_treeb_dist",
      Count = 8
    },
    {
      Name = "intro_fountain",
      Count = 1
    },
    {
      Name = "intro_lantern_pop",
      Count = 5
    },
    {
      Name = "intro_terraint2",
      Count = 1
    },
    {
      Name = "intro_bridgewipe",
      Count = 1
    },
    {
      Name = "intro_towerwipe",
      Count = 1
    },
    {
      Name = "Intro_LanternOn",
      Count = 12
    },
    {
      Name = "Intro_GazeboSparkman",
      Count = 1
    },
    {
      Name = "Intro_BlueSparkPaths",
      Count = 1
    },
    {
      Name = "Intro_BlueSparkMover",
      Count = 10
    },
    {
      Name = "Intro_POP_TreeMedium",
      Count = 6
    },
    {
      Name = "Intro_Sparks",
      Count = 4
    },
    {
      Name = "Intro_FireworksA",
      Count = 1
    },
    {
      Name = "Intro_SparksLight",
      Count = 2
    },
    {
      Name = "intro_sparkimpactb",
      Count = 1
    },
    {
      Name = "pickupsparkb",
      Count = 6
    },
    {
      Name = "PickupSparkC",
      Count = 10
    }
  },
  Intro_ToyField = {
    {
      Name = "Intro_SkyDive_CloudsA",
      Count = 4
    },
    {
      Name = "Intro_SkyDive_CloudsB",
      Count = 4
    },
    {
      Name = "Intro_ZurbotImpact",
      Count = 12
    },
    {
      Name = "inc_flightfx",
      Count = 1
    },
    {
      Name = "intro_zurgbot_proj",
      Count = 48
    },
    {
      Name = "intro_zurbotimpact",
      Count = 48
    },
    {
      Name = "intro_zurgbot_proj_lrg",
      Count = 5
    },
    {
      Name = "ts_jetpack_lightson",
      Count = 1
    },
    {
      Name = "Intro_SparksLight",
      Count = 1
    },
    {
      Name = "intro_dc_tree",
      Count = 1
    },
    {
      Name = "intro_BlueSparkOut",
      Count = 5
    }
  },
  Intro_Cars = {
    {
      Name = "Intro_AvitarSparkPopBlue",
      Count = 12
    },
    {
      Name = "Intro_JumpTranslate",
      Count = 1
    },
    {
      Name = "Celeb_CAR_Small",
      Count = 1
    }
  },
  Intro_Incredibles = {
    {Name = "pc_firea", Count = 4},
    {
      Name = "Bld_DamageTS_Spark",
      Count = 1
    },
    {
      Name = "INC_Pop_TreeGrowA",
      Count = 2
    },
    {Name = "ExplosionB", Count = 1},
    {
      Name = "Intro_INC_ExplodeA",
      Count = 1
    },
    {
      Name = "inc_carpartsexplode",
      Count = 1
    },
    {
      Name = "intro_inc_bush",
      Count = 1
    },
    {
      Name = "bh_copmuzflash",
      Count = 2
    },
    {
      Name = "omnib_explaoe",
      Count = 1
    }
  },
  Intro_Characters = {
    {
      Name = "pickupsparka",
      Count = 1
    },
    {
      Name = "Intro_SparksLight",
      Count = 6
    },
    {
      Name = "Intro_AvitarSparkPop",
      Count = 1
    },
    {
      Name = "Intro_AvitarSparkTransitionBlue",
      Count = 1
    },
    {
      Name = "Intro_AvitarSparkTransition",
      Count = 1
    },
    {
      Name = "Intro_SparksWTWoody",
      Count = 1
    },
    {
      Name = "Intro_trainwheel",
      Count = 1
    },
    {
      Name = "Intro_WT_Cactus2",
      Count = 2
    },
    {
      Name = "Intro_WT_Cactus",
      Count = 2
    },
    {
      Name = "intro_wttrain",
      Count = 1
    }
  },
  Intro_Pirates = {
    {
      Name = "intro_avitarsparktransition",
      Count = 1
    },
    {
      Name = "intro_mu_flowerb",
      Count = 4
    },
    {
      Name = "intro_mu_flowerc",
      Count = 3
    },
    {
      Name = "Intro_POP_PIR_Palm_B",
      Count = 6
    },
    {
      Name = "Intro_POP_PIR_Palm_A",
      Count = 2
    },
    {
      Name = "intro_vinenoflower",
      Count = 1
    },
    {
      Name = "RR_JetBarrelEngine",
      Count = 1
    },
    {
      Name = "Intro_JetBarrel",
      Count = 1
    },
    {
      Name = "rr_objectbeacon_customization",
      Count = 1
    },
    {
      Name = "rr_objectstateinvalid",
      Count = 1
    },
    {
      Name = "rr_objectstatespawn",
      Count = 1
    },
    {
      Name = "Intro_CannonTranslate",
      Count = 1
    }
  }
}
L4_4 = "LoadVehicleMeridianData"
L3_3[L4_4] = true
L4_4 = false
L3_3.displayAvatarInfoHud = L4_4
L4_4 = true
L3_3.worldIsIntro = L4_4
L2_2.Intro = L3_3
L3_3 = "PC_CalypsoBayou"
L4_4 = {}
L4_4.DefaultAvatar = "PIR_JackSparrow"
L4_4.PlaysetProperties = "Pirates"
L4_4.DefaultAvatar3 = "PIR_Barbossa"
L4_4.Portals = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L4_4.DefaultAvatar2 = "PIR_DavyJones"
L4_4.MasterZone = "PC_OceanMaster"
L4_4.DefaultAvatar4 = "PIR_JackSparrow"
L4_4.worldIsPlayset = true
L4_4.inventoryFilter = "LVL_PIRATES"
L4_4._ShowInMenu_ = false
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_POTC_Barbosa"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "PIR_DavyJones"
L4_4.DefaultAvatar = "PIR_Barbossa"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "PIR_Barbossa"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_Islet_Arch"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.PlaysetProperties = "Pirates"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_Islet_Arch_tunnel = L3_3
L3_3 = "ADV_IGP_LR_Tonto"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "LR_LoneRanger"
L4_4.DefaultAvatar = "LR_Tonto"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "LR_Tonto"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_WR_Ralph"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "WR_Vanellope"
L4_4.DefaultAvatar = "WR_Ralph"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "WR_Ralph"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_WR_Vanellope"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "WR_Ralph"
L4_4.DefaultAvatar = "WR_Vanellope"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "WR_Vanellope"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "CA_RadiatorSprings"
L4_4 = {}
L4_4.DefaultAvatar = "AV_McQueen"
L4_4.PlaysetProperties = "Cars"
L4_4.DefaultAvatar3 = "AV_Cars_Finn"
L4_4.DefaultAvatar2 = "AV_Mater"
L4_4.MasterZone = "CA_Master"
L4_4.Portals = {
  {
    Link = "CA_TunnelConnector"
  }
}
L4_4.worldIsPlayset = true
L4_4.SAVE_INVENTORY = true
L4_4.DefaultAvatar4 = "AV_Holly"
L4_4.splitScreenHorizontal = true
L2_2[L3_3] = L4_4
L3_3 = "RumpusRoom_Flow01"
L4_4 = {}
L4_4.displayAvatarInfoHud = false
L4_4.lock = "TBX_WORLD_FLOW"
L4_4.worldExtentMaxY = 512
L4_4.worldExtentCenterY = 512
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = "PC_Islet_Claw"
L4_4 = {}
L4_4.DefaultAvatar = "PIR_JackSparrow"
L4_4.PlaysetProperties = "Pirates"
L4_4.DefaultAvatar3 = "PIR_Barbossa"
L4_4.Portals = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L4_4.DefaultAvatar2 = "PIR_DavyJones"
L4_4.MasterZone = "PC_OceanMaster"
L4_4.DefaultAvatar4 = "PIR_JackSparrow"
L4_4.worldIsPlayset = true
L4_4.inventoryFilter = "LVL_PIRATES"
L4_4._ShowInMenu_ = false
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = "ADV_RAC_LapRace_D"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.CombatTeamPerceptionEnabled = false
L4_4.ZonePath = "Worlds/ADV_RAC_LapRace_A/ADV_RAC_LapRace_A"
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.ADV_LapRace_Start_Position = 4
L4_4.AutoSaveEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_TUT_Combat_Act_1"
L4_4 = {}
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.IsAdventure = true
L4_4.CombatTeamPerceptionEnabled = true
L4_4.AutoSaveEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_TUT_Logic"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.CombatTeamPerceptionEnabled = false
L4_4.AutoSaveEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "RumpusRoom_Simple"
L4_4 = {}
L4_4.AllowUGC = true
L4_4.lock = "TBX_WORLD_SIMPLE"
L4_4.worldExtentMaxY = 512
L4_4.worldExtentCenterY = 512
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_POTC_DaveyJ"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "PIR_Barbossa"
L4_4.DefaultAvatar = "PIR_DavyJones"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "PIR_DavyJones"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.DefaultAvatar = "PIR_JackSparrow"
L3_3.PlaysetProperties = "Pirates"
L3_3.DefaultAvatar3 = "PIR_Barbossa"
L4_4 = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L3_3.Portals = L4_4
L3_3.DefaultAvatar2 = "PIR_DavyJones"
L3_3.MasterZone = "PC_OceanMaster"
L3_3.DefaultAvatar4 = "PIR_JackSparrow"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L2_2.PC_Islet_Jug = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_Islet_Volcano"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.PlaysetProperties = "Pirates"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_Islet_Volcano_tunnel = L3_3
L3_3 = "PC_Islet_Arch"
L4_4 = {}
L4_4.DefaultAvatar = "PIR_JackSparrow"
L4_4.PlaysetProperties = "Pirates"
L4_4.DefaultAvatar3 = "PIR_Barbossa"
L4_4.Portals = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L4_4.DefaultAvatar2 = "PIR_DavyJones"
L4_4.MasterZone = "PC_OceanMaster"
L4_4.DefaultAvatar4 = "PIR_JackSparrow"
L4_4.worldIsPlayset = true
L4_4.inventoryFilter = "LVL_PIRATES"
L4_4._ShowInMenu_ = false
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_CARS_McQueen"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_Mater"
L4_4.DefaultAvatar = "AV_McQueen"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "AV_McQueen"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_CARS_Holley"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_Mater"
L4_4.DefaultAvatar = "AV_Holly"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.UseCarsWeaponLocks = false
L4_4.RequiredAvatar = "AV_Holly"
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_CARS_Francesco"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_McQueen"
L4_4.DefaultAvatar = "AV_Cars_Francesco"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "AV_Cars_Francesco"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.UIPlaysetFilter = "Developer_Worlds"
L4_4 = 512
L3_3.worldExtentMaxY = L4_4
L4_4 = 512
L3_3.worldExtentCenterY = L4_4
L3_3.PlaysetProperties = "RumpusRoom"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L2_2.RumpusRoom = L3_3
L3_3 = "ADV_TUT_IPAD_Building"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.CombatTeamPerceptionEnabled = false
L4_4.AutoSaveEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "RumpusRoom_MU"
L4_4 = {}
L4_4.AllowUGC = true
L4_4.lock = "TBX_WORLD_MU"
L4_4.worldExtentMaxY = 512
L4_4.worldExtentCenterY = 512
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = "ADV_RAC_LapRace_A"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.CombatTeamPerceptionEnabled = false
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.ADV_LapRace_Start_Position = 0
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_GEN_Mickey"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_Woody"
L4_4.DefaultAvatar = "TB_MickeyMouse"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "TB_MickeyMouse"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_INC_Dash"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_Violet"
L4_4.DefaultAvatar = "AV_Dash"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "AV_Dash"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_POTC_Jack"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "PIR_Barbossa"
L4_4.DefaultAvatar = "PIR_JackSparrow"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "PIR_JackSparrow"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = {}
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.PlaysetProperties = "ToyStoryInSpace"
L3_3.DefaultAvatar3 = "AV_Jessie"
L3_3.DefaultAvatar2 = "AV_Woody"
L3_3.MasterZone = "TS_Master"
L4_4 = {
  {
    Link = "TS_CombatSimTunnel"
  }
}
L3_3.Portals = L4_4
L4_4 = true
L3_3.worldIsPlayset = L4_4
L3_3.DefaultAvatar = "AV_Buzz"
L3_3.DefaultAvatar4 = "AV_Buzz"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L2_2.TS_CombatSim = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_BuccaneerBay"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.PlaysetProperties = "Pirates"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_BuccaneerBay_tunnel = L3_3
L3_3 = {}
L3_3.DefaultAvatar = "PIR_JackSparrow"
L3_3.PlaysetProperties = "Pirates"
L3_3.DefaultAvatar3 = "PIR_Barbossa"
L4_4 = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L3_3.Portals = L4_4
L3_3.DefaultAvatar2 = "PIR_DavyJones"
L3_3.MasterZone = "PC_OceanMaster"
L3_3.DefaultAvatar4 = "PIR_JackSparrow"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L2_2.PC_FortStGrande = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_CalypsoBayou"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.PlaysetProperties = "Pirates"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_CalypsoBayou_tunnel = L3_3
L3_3 = {}
L3_3.DefaultAvatar = "MU_Sully"
L3_3.PlaysetProperties = "MonstersU"
L4_4 = "ZoneCatalogExcludeList"
L3_3[L4_4] = ""
L3_3.InventoryFilter = "LVL_MONSTERS"
L4_4 = true
L3_3.CarsNeedDrivers = L4_4
L4_4 = false
L3_3.ThrownCarsDoDamage = L4_4
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L4_4 = true
L3_3.TrafficQuarterback = L4_4
L4_4 = {
  {
    Link = "MU_Tunnel_Campus_FratRow"
  }
}
L3_3.Portals = L4_4
L3_3.IdleAnimEvent = "IDLE"
L3_3.DefaultAvatar2 = "MU_Mike"
L3_3.MasterZone = "MU_Master"
L3_3.WalkAnimEvent = "MOVE"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3.CarsShouldHonk = L4_4
L4_4 = false
L3_3.FloatingCars = L4_4
L4_4 = "AllowSpeeder"
L3_3[L4_4] = false
L2_2.MU_FratRow = L3_3
L3_3 = "PC_Islet_Lighthouse"
L4_4 = {}
L4_4.DefaultAvatar = "PIR_JackSparrow"
L4_4.PlaysetProperties = "Pirates"
L4_4.DefaultAvatar3 = "PIR_Barbossa"
L4_4.Portals = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L4_4.DefaultAvatar2 = "PIR_DavyJones"
L4_4.MasterZone = "PC_OceanMaster"
L4_4.DefaultAvatar4 = "PIR_JackSparrow"
L4_4.worldIsPlayset = true
L4_4.inventoryFilter = "LVL_PIRATES"
L4_4._ShowInMenu_ = false
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.PlaysetProperties = "Cars"
L3_3.DefaultAvatar3 = "AV_Cars_Finn"
L4_4 = {
  {
    Blocker = "RadSprings_Blocker_Willys",
    Link = "CA_WillysButte"
  },
  {
    Blocker = "RadSprings_Blocker_Rad",
    Link = "CA_RadiatorSprings"
  }
}
L3_3.Portals = L4_4
L3_3.DefaultAvatar2 = "AV_Mater"
L3_3.MasterZone = "CA_Master"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L4_4 = true
L3_3.worldIsPlayset = L4_4
L3_3.DefaultAvatar = "AV_McQueen"
L3_3.DefaultAvatar4 = "AV_Holly"
L4_4 = true
L3_3.splitScreenHorizontal = L4_4
L2_2.CA_TunnelConnector = L3_3
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_ShipwreckShoals"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.PlaysetProperties = "Pirates"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_ShipwreckShoals_tunnel = L3_3
L3_3 = "PC_Islet_Volcano"
L4_4 = {}
L4_4.DefaultAvatar = "PIR_JackSparrow"
L4_4.PlaysetProperties = "Pirates"
L4_4.DefaultAvatar3 = "PIR_Barbossa"
L4_4.Portals = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L4_4.DefaultAvatar2 = "PIR_DavyJones"
L4_4.MasterZone = "PC_OceanMaster"
L4_4.DefaultAvatar4 = "PIR_JackSparrow"
L4_4.worldIsPlayset = true
L4_4.inventoryFilter = "LVL_PIRATES"
L4_4._ShowInMenu_ = false
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = "ADV_CBT_Arena"
L4_4 = {}
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.IsAdventure = true
L4_4.CombatTeamPerceptionEnabled = true
L4_4.AutoSaveEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_INC_Violet"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_Dash"
L4_4.DefaultAvatar = "AV_Violet"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "AV_Violet"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_INC_Syndrome"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_ElastiGirl"
L4_4.DefaultAvatar = "AV_Syndrome"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "AV_Syndrome"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_TS_Woody"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "AV_Jessie"
L4_4.DefaultAvatar = "AV_Woody"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "AV_Woody"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "RumpusRoom_renderer_approvals"
L4_4 = {}
L4_4.UIPlaysetFilter = "Developer_Worlds"
L4_4.worldExtentCenterY = 512
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.worldExtentMaxY = 512
L2_2[L3_3] = L4_4
L3_3 = "LR_Colby"
L4_4 = {}
L4_4.DefaultAvatar = "LR_LoneRanger"
L4_4.PlaysetProperties = "LoneRanger"
L4_4.RecycleInNearDistancePeds = 40
L4_4.inventoryFilter = "LVL_LONERANGER"
L4_4.RecycleOutNearDistancePeds = 50
L4_4.EdgeOfWorldQuarterback = {WarningZoneRealm = "RLM_LR_EOW"}
L4_4.ThrownCarsDoDamage = false
L4_4.PedestrianList4 = {
  "Blockhead(LR_Baron)",
  "Blockhead(LR_Miner)",
  "Blockhead(LR_Gilles)"
}
L4_4.RecycleInFarDistancePeds = 60
L4_4.SAVE_INVENTORY = true
L4_4.ZoneType = "Master"
L4_4.CarsShouldHonk = false
L4_4.PedestrianList2 = {
  "Blockhead(LR_Shawman)"
}
L4_4.RecycleOutFarDistancePeds = 70
L4_4.PedestrianList1 = {
  "Blockhead(LR_SnakeLady)",
  "Blockhead(LR_PhantomNose)",
  "Blockhead(LR_BisonHead)",
  "Blockhead(LR_BeardedLady)",
  "Blockhead(LR_BeakMask)",
  "Blockhead(LR_DevilMask)",
  "Blockhead(LR_HornedMask)",
  "Blockhead(LR_PeacockFace)"
}
L4_4.PedestrianList0 = {
  "Blockhead(LR_Plain)",
  "Blockhead(LR_Granny)",
  "Blockhead(LR_OldTimer)",
  "Blockhead(LR_Horseman)",
  "Blockhead(LR_Trader)",
  "Blockhead(LR_Laura)",
  "Blockhead(LR_Merchant)",
  "Blockhead(LR_Bonnet)",
  "Blockhead(LR_Blondee)",
  "Blockhead(LR_Baron)",
  "Blockhead(LR_Almonzo)"
}
L4_4.TrafficQuarterback = true
L4_4.DefaultAvatar3 = "LR_LoneRanger"
L4_4.IdleAnimEvent = "IDLE"
L4_4.DefaultAvatar2 = "LR_Tonto"
L4_4.WalkAnimEvent = "MOVE"
L4_4.PedestrianList3 = {
  "Blockhead(LR_Soldier)"
}
L4_4.worldIsPlayset = true
L4_4.CarsNeedDrivers = false
L4_4.FloatingCars = false
L4_4.DefaultAvatar4 = "LR_Tonto"
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.DefaultAvatar = "AV_Buzz"
L4_4 = {
  "TrafficCar(Spaceship)",
  "TrafficCar(Spaceship2)",
  "TrafficCar(Spaceship3)",
  "TrafficCar(Spaceship4)"
}
L3_3.CarList0 = L4_4
L3_3.PlaysetProperties = "ToyStoryInSpace"
L4_4 = "TunnelBlockerLoadingCho"
L3_3[L4_4] = "UI_ZoneLoad"
L4_4 = {}
L4_4.WarningZoneRealm = "RLM_TS_EOW"
L3_3.EdgeOfWorldQuarterback = L4_4
L4_4 = false
L3_3.ThrownCarsDoDamage = L4_4
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.ZoneType = "Master"
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L4_4 = "PhysicsTimeStep"
L3_3[L4_4] = 0.043478260869565
L4_4 = {
  "Blockhead(TS_Alien)"
}
L3_3.PedestrianList0 = L4_4
L4_4 = true
L3_3.TrafficQuarterback = L4_4
L3_3.DefaultAvatar3 = "AV_Jessie"
L3_3.DefaultAvatar2 = "AV_Woody"
L4_4 = false
L3_3.CarsShouldHonk = L4_4
L4_4 = "EnterAndExitBuildingsEnabled"
L3_3[L4_4] = false
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3.CarsNeedDrivers = L4_4
L4_4 = true
L3_3.FloatingCars = L4_4
L3_3.DefaultAvatar4 = "AV_Buzz"
L2_2.TS_Master = L3_3
L3_3 = {}
L3_3.DefaultAvatar = "AV_Buzz"
L3_3.PlaysetProperties = "ToyStoryInSpace"
L3_3.DefaultAvatar3 = "AV_Jessie"
L3_3.DefaultAvatar2 = "AV_Woody"
L3_3.MasterZone = "TS_Master"
L4_4 = -10
L3_3.RealmBlendOffset = L4_4
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = {
  {
    Link = "TS_GooValleyTunnel"
  },
  {
    Link = "TS_CombatSimTunnel"
  }
}
L3_3.Portals = L4_4
L3_3.DefaultAvatar4 = "AV_Buzz"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L2_2.TS_MainTown = L3_3
L3_3 = {}
L3_3.DefaultAvatar = "MU_Sully"
L3_3.PlaysetProperties = "MonstersU"
L3_3.InventoryFilter = "LVL_MONSTERS"
L4_4 = true
L3_3.CarsNeedDrivers = L4_4
L4_4 = false
L3_3.ThrownCarsDoDamage = L4_4
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L4_4 = true
L3_3.TrafficQuarterback = L4_4
L4_4 = {
  {
    Link = "MU_Tunnel_Campus_FT"
  }
}
L3_3.Portals = L4_4
L4_4 = "DetentionCenter"
L3_3[L4_4] = true
L3_3.DefaultAvatar2 = "MU_Mike"
L3_3.MasterZone = "MU_Master"
L3_3.IdleAnimEvent = "IDLE"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L3_3.WalkAnimEvent = "MOVE"
L4_4 = false
L3_3.FloatingCars = L4_4
L4_4 = false
L3_3.CarsShouldHonk = L4_4
L2_2.MU_FearTech = L3_3
L3_3 = "RumpusRoom_Dragon"
L4_4 = {}
L4_4.AllowUGC = true
L4_4.lock = "TBX_WORLD_DRAGON"
L4_4.worldExtentMaxY = 512
L4_4.worldExtentCenterY = 512
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.PlaysetProperties = "Pirates"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_DemonsCape_tunnel = L3_3
L3_3 = "PC_BuccaneerBay"
L4_4 = {}
L4_4.DefaultAvatar = "PIR_JackSparrow"
L4_4.PlaysetProperties = "Pirates"
L4_4.DefaultAvatar3 = "PIR_Barbossa"
L4_4.Portals = {
  {
    Link = "PC_BuccaneerBay_tunnel"
  },
  {
    Link = "PC_CalypsoBayou_tunnel"
  },
  {
    Link = "PC_DeadMansCove_tunnel"
  },
  {
    Link = "PC_ShipwreckShoals_tunnel"
  },
  {
    Link = "PC_FortStGrande_tunnel"
  },
  {
    Link = "PC_Islet_Claw_tunnel"
  },
  {
    Link = "PC_Islet_Arch_tunnel"
  },
  {
    Link = "PC_Islet_Lighthouse_tunnel"
  },
  {
    Link = "PC_Islet_Jug_tunnel"
  },
  {
    Link = "PC_Islet_Fort_tunnel"
  },
  {
    Link = "PC_Islet_Volcano_tunnel"
  },
  {
    Link = "PC_DemonsCape_tunnel"
  },
  {
    Link = "PC_Heidis_Secret_Ships"
  }
}
L4_4.DefaultAvatar2 = "PIR_DavyJones"
L4_4.MasterZone = "PC_OceanMaster"
L4_4.DefaultAvatar4 = "PIR_JackSparrow"
L4_4.worldIsPlayset = true
L4_4.inventoryFilter = "LVL_PIRATES"
L4_4._ShowInMenu_ = true
L4_4.SAVE_INVENTORY = true
L2_2[L3_3] = L4_4
L3_3 = "ADV_IGP_GEN_JSkell"
L4_4 = {}
L4_4.IsAdventure = true
L4_4.DefaultAvatar2 = "TAN_Rapunzel"
L4_4.DefaultAvatar = "NBC_JackSkellington"
L4_4.AutoSaveEnabled = false
L4_4.PlaysetProperties = "RumpusRoom"
L4_4.RequiredAvatar = "NBC_JackSkellington"
L4_4.CombatTeamPerceptionEnabled = false
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_Islet_Claw"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.PlaysetProperties = "Pirates"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_Islet_Claw_tunnel = L3_3
L3_3 = "frontend"
L4_4 = {}
L4_4.IsFrontEnd = true
L4_4.PlaysetProperties = "Miscellaneous"
L4_4._ShowInMenu_ = false
L4_4.AutoSaveEnabled = false
L2_2[L3_3] = L4_4
L3_3 = "CoreMechanics"
L4_4 = {}
L4_4.PlaysetProperties = "Miscellaneous"
L2_2[L3_3] = L4_4
L3_3 = {}
L3_3.ZoneType = "Tunnel"
L4_4 = {
  {
    Link = "PC_Islet_Lighthouse"
  }
}
L3_3.Portals = L4_4
L3_3.MasterZone = "PC_OceanMaster"
L4_4 = true
L3_3.SAVE_INVENTORY = L4_4
L3_3.PlaysetProperties = "Pirates"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = false
L3_3._ShowInMenu_ = L4_4
L3_3.inventoryFilter = "LVL_PIRATES"
L2_2.PC_Islet_Lighthouse_tunnel = L3_3
L1_1.Zones = L2_2
L2_2 = "GlobalData"
L3_3 = {}
L4_4 = "OrderedPlaysets"
L3_3[L4_4] = {
  {
    Name = "Incredibles",
    availableInPRBuild = true
  },
  {Name = "MonstersU", availableInPRBuild = true},
  {Name = "Pirates", availableInPRBuild = true},
  {Name = "Cars", availableInPRBuild = false},
  {Name = "LoneRanger", availableInPRBuild = false},
  {
    Name = "ToyStoryInSpace",
    availableInPRBuild = false
  },
  {
    Name = "Miscellaneous",
    availableInPRBuild = false
  },
  {Name = "HoloDecks", availableInPRBuild = false},
  {Name = "RumpusRoom", availableInPRBuild = true}
}
L1_1[L2_2] = L3_3
L2_2 = {}
L3_3 = {}
L4_4 = "CustomizeCho1"
L3_3[L4_4] = "MU_CharacterCustomizeA"
L4_4 = "PlaysetUniqueID"
L3_3[L4_4] = 5
L4_4 = "playsetDict"
L3_3[L4_4] = "MU"
L4_4 = "StartWorld"
L3_3[L4_4] = "MU_Campus"
L4_4 = "avatarSuffix"
L3_3[L4_4] = "_PS"
L4_4 = "WorldIcon"
L3_3[L4_4] = "IN_LOGO_Monsters"
L3_3.inventoryFilter = "LVL_MONSTERS"
L4_4 = "AgentBudgetGroups"
L3_3[L4_4] = {
  Transports = {
    MaxAgents = 13,
    DefaultUnloadPriority = "TransportUnloadPriority",
    SubBudgets = {
      {
        ActorTypeFilter = "MU_Bicycle",
        IsMaxPerPlayer = true,
        MaxAgents = 1
      },
      {
        ActorTypeFilter = "MU_Archie",
        IsMaxPerPlayer = true,
        MaxAgents = 1
      },
      {
        ActorTypeFilter = "MU_Ramp",
        IsMaxPerPlayer = false,
        MaxAgents = 1
      },
      {
        ActorTypeFilter = "AgentBudget_Transport"
      },
      {
        UnloadPriority = "DriveableUnloadPriority",
        ActorTypeFilter = "AgentBudget_Transport_Vehicle"
      }
    }
  }
}
L4_4 = "enteredLockName"
L3_3[L4_4] = "ACH_MOSTERSU_ENTERED"
L4_4 = "blockheadCustomizationFilter"
L3_3[L4_4] = "Monsters"
L4_4 = "MissionParams"
L3_3[L4_4] = {
  EncounterAudio_MaxMissionEncounterDelay = 120,
  ActivationLikelihood = 30,
  MissionRewardsFile = "MU_MissionRewards.lua",
  MissionCelebrationChoMedium = "Celeb_MU_Large_Container",
  MissionCelebrationChoLarge = "Celeb_MU_Large_Container",
  MissionCelebrationReactLarge = "celb",
  BeaconMap = {
    {
      "MissionAvailableDefault",
      "Beacon_Missions_Excl",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveDefault",
      "Beacon_Missions_Ques",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailableAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailable_Activity",
      "Beacon_Missions_Excl",
      "Layout|PlacementA"
    },
    {
      "MissionActive_Activity",
      "Beacon_Missions_Ques",
      "Layout|PlacementA"
    },
    {
      "MissionAvailableAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionActiveAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionAvailable_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "FocusPointNone",
      "",
      "",
      0
    },
    {
      "FocusPointDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultShort",
      "Beacon_Mission_Arrow_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultArrowOnly",
      "Beacon_Mission_Arrow_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefault",
      "Beacon_Mission_ArrowRed",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultShort",
      "Beacon_Mission_ArrowRed_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultArrowOnly",
      "Beacon_Mission_ArrowRed_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointAlertDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "TS_BeaconGen",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "Beacon_Mission_Target",
      "Beacon_Mission_Target",
      "Layout|PlacementA",
      0
    }
  },
  EncounterAudio_MinWaitAfterPresentation = 15,
  MissionLogOrder = 4,
  EncounterAudio_MinMissionEncounterDelay = 30,
  EncounterAudio_SelectedWeightModifier = 3.5,
  SelectedWeightModifier = 3.5,
  UnselectedWeightModifier = 1.5,
  MinAlertDelayHigh = 20,
  MissionCompleteAudioStringer = "",
  MissionCelebrationChoSmall = "Celeb_MU_Small",
  MissionTalkDelay = 0,
  ActivationRange = 40,
  FindMGReqMissions = {
    "mu_campus_Story_MissionTutorial"
  },
  MissionAcceptedVO = "Avatar_Mission_Accept",
  DeactivationRange = 60,
  EncounterAudio_UnselectedWeightModifier = 1.5,
  MissionCelebrationReactSmall = "",
  ControlledMissionDelay = 1,
  EncounterAudio_MinWeight = 1,
  EncounterAudio_StartWeight = 10,
  StarsAvailable = 100,
  EncounterAudio_ActivationRange = 15,
  EncounterAudio_MissionEncounterDelayArmed = 5,
  MissionCelebrationReactMedium = "celb",
  MissionCompleteDelay = 1,
  DefaultRewardType = "INV_MONSTERS_CURRENCY",
  MinAlertDelayLow = 10,
  MaxActiveMissions = 10
}
L4_4 = "Type"
L3_3[L4_4] = "Playset"
L4_4 = "vertexbufferHeapSize360"
L3_3[L4_4] = 29360128
L4_4 = "ShowDamageNumbers"
L3_3[L4_4] = false
L4_4 = "vertexbufferHeapSizePS3"
L3_3[L4_4] = 34603008
L4_4 = "starName"
L3_3[L4_4] = "MONSTERSU_STAR"
L4_4 = "TransportManager"
L3_3[L4_4] = {
  {
    ActorCreationKey = "",
    ActorType = "Transport_NONE"
  },
  {
    Lock = "RC_MU_ARCHIE",
    ActorTag = "MU_Archie",
    ActorCreationKey = "MU_Archie",
    ActorType = "MU_Archie"
  },
  {
    Lock = "RC_MU_BIKE",
    ActorTag = "Player_MU_Bicycle",
    ActorCreationKey = "MU_Bicycle",
    ActorType = "MU_Bicycle"
  },
  {
    ActorState = "Small",
    ActorCreationKey = "MU_Bicycle_Mini",
    ActorType = "MU_Bicycle",
    Lock = "RC_MU_BIKE_MINI",
    ActorTag = "Player_MU_Bicycle_Mini"
  },
  {
    Lock = "RC_MU_BIKE_RANDY",
    ActorTag = "Player_MU_Bicycle",
    ActorCreationKey = "MU_Bicycle_Randall",
    ActorType = "MU_Bicycle"
  },
  {
    Lock = "RC_MU_BIKE_SULLEY",
    ActorTag = "Player_MU_Bicycle",
    ActorCreationKey = "MU_Bicycle_Sully",
    ActorType = "MU_Bicycle"
  },
  {
    Lock = "RC_MU_BIKE_RAMP",
    ActorTag = "MU_Ramp",
    ActorCreationKey = "MU_Ramp",
    ActorType = "MU_Ramp"
  }
}
L4_4 = "ZoneCatalogExcludeList"
L3_3[L4_4] = "RC_MU_BLD_ROR,RC_MU_BLD_JOX,RC_MU_BLD_HSS,RC_MU_BLD_EKO,RC_MU_BLD_PNK,RC_MU_Bike_Park_Duel_Pool,RC_MU_Bike_Park_Half_Pipe,RC_MU_Bike_Park_Berm,RC_MU_Bike_Park_TableTop,RC_MU_Bike_Park_FunJump"
L4_4 = "completedLockName"
L3_3[L4_4] = "ACH_MONSTERSU_COMPLETED"
L4_4 = "WantBloatFX"
L3_3[L4_4] = true
L4_4 = "PlayableAvatars"
L3_3[L4_4] = "AV_MrIncredible,AV_ElastiGirl,AV_Dash,AV_Violet,AV_Syndrome,AV_Frozone,PIR_JackSparrow,PIR_Barbossa,PIR_DavyJones,MU_Sully,MU_Mike,MU_Randall,LR_LoneRanger,LR_Tonto,AV_Buzz,AV_Jessie,AV_Woody,AV_Zurg,AV_McQueen,AV_Holly,AV_Mater,AV_Francesco,AV_Cars_Finn,AV_Cars_Luigi,AV_Cars_Ramone,AV_Cars_Flo,AV_Cars_ChickHicks,AV_Cars_King,AV_Cars_Carla,AV_Cars_Shu,AV_Fillmore,FRO_Anna,FRO_Elsa,NBC_JackSkellington,TB_MickeyMouse,PNF_Phineas,PNF_Perry,WR_Ralph,WR_Vanellope,TAN_Rapunzel"
L4_4 = "ComboPointsMeter"
L3_3[L4_4] = "ComboCacheMeter"
L4_4 = true
L3_3.worldIsPlayset = L4_4
L4_4 = "LoadVehicleMeridianData"
L3_3[L4_4] = true
L4_4 = "ActivityTypeDataFile"
L3_3[L4_4] = "ActivityTypeData_MU.lua"
L4_4 = "LoadingScreen_MU"
L3_3.LoadingScreen = L4_4
L2_2.MonstersU = L3_3
L3_3 = {}
L4_4 = "PlaysetUniqueID"
L3_3[L4_4] = 8
L4_4 = "playsetDict"
L3_3[L4_4] = "TB"
L4_4 = "StartWorld"
L3_3[L4_4] = "Intro"
L4_4 = "WorldIcon"
L3_3[L4_4] = "IN_LOGO_ToyBox"
L4_4 = "LVL_RUMPUSROOM"
L3_3.inventoryFilter = L4_4
L4_4 = "AllowPlaceObjectFromCatalog"
L3_3[L4_4] = false
L4_4 = {}
L4_4.EdgeOfWorldBounds = 1024
L3_3.EdgeOfWorldQuarterback = L4_4
L4_4 = "AllowPlaceEditorOnBackButton"
L3_3[L4_4] = true
L4_4 = "AllowCurrencyHUD"
L3_3[L4_4] = true
L4_4 = "blockheadCustomizationFilter"
L3_3[L4_4] = ""
L4_4 = "MissionParams"
L3_3[L4_4] = {
  EncounterAudio_MaxMissionEncounterDelay = 120,
  ActivationLikelihood = 100,
  MissionRewardsFile = "MissionRewards.lua",
  MissionCelebrationChoMedium = "Celeb_INF_Large",
  MissionCelebrationChoLarge = "Celeb_INF_Large",
  MissionCelebrationReactLarge = "celb",
  BeaconMap = {
    {
      "MissionAvailableDefault",
      "Beacon_Missions_Excl",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveDefault",
      "Beacon_Missions_Ques",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailableAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailable_Activity",
      "Beacon_Missions_Excl",
      "Layout|PlacementA"
    },
    {
      "MissionActive_Activity",
      "Beacon_Missions_Ques",
      "Layout|PlacementA"
    },
    {
      "MissionAvailableAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionActiveAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionAvailable_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "FocusPointNone",
      "",
      "",
      0
    },
    {
      "FocusPointDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultShort",
      "Beacon_Mission_Arrow_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultArrowOnly",
      "Beacon_Mission_Arrow_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefault",
      "Beacon_Mission_ArrowRed",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultShort",
      "Beacon_Mission_ArrowRed_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultArrowOnly",
      "Beacon_Mission_ArrowRed_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointAlertDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "TS_BeaconGen",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "Beacon_Mission_Target",
      "Beacon_Mission_Target",
      "Layout|PlacementA",
      0
    }
  },
  EncounterAudio_MinWaitAfterPresentation = 15,
  MissionLogOrder = 0,
  EncounterAudio_MinMissionEncounterDelay = 30,
  EncounterAudio_SelectedWeightModifier = 3.5,
  SelectedWeightModifier = 0,
  UnselectedWeightModifier = 0,
  MinAlertDelayHigh = 20,
  MissionCompleteAudioStringer = "",
  MissionCelebrationChoSmall = "Celeb_INF_Small",
  MissionTalkDelay = 0,
  ActivationRange = 40,
  MissionAcceptedVO = "Avatar_Mission_Accept",
  DeactivationRange = 6000,
  EncounterAudio_UnselectedWeightModifier = 1.5,
  MissionCelebrationReactSmall = "",
  ControlledMissionDelay = 1,
  EncounterAudio_MinWeight = 1,
  EncounterAudio_StartWeight = 10,
  StarsAvailable = 100,
  EncounterAudio_ActivationRange = 15,
  EncounterAudio_MissionEncounterDelayArmed = 5,
  MissionCelebrationReactMedium = "celb",
  MissionCompleteDelay = 0.1,
  DefaultRewardType = "INV_SPARKS",
  MinAlertDelayLow = 10,
  MaxActiveMissions = 1
}
L4_4 = "Type"
L3_3[L4_4] = "RumpusRoom"
L4_4 = true
L3_3.CombatTeamPerceptionEnabled = L4_4
L4_4 = "AllowInventoryInPauseMenu"
L3_3[L4_4] = true
L4_4 = "WantToyBoxFX"
L3_3[L4_4] = true
L4_4 = "WantBloatFX"
L3_3[L4_4] = true
L4_4 = "TransportManager"
L3_3[L4_4] = {
  {
    ActorCreationKey = "",
    ActorType = "Transport_NONE"
  },
  {
    ActorTag = "TB_Kahn",
    ActorCreationKey = "TB_Kahn",
    ActorType = "TB_Kahn"
  },
  {
    ActorTag = "TB_Abu",
    ActorCreationKey = "TB_Abu",
    ActorType = "TB_Abu"
  },
  {
    ActorTag = "TB_Maximus",
    ActorCreationKey = "TB_Maximus",
    ActorType = "TB_Maximus"
  },
  {
    ActorTag = "TB_Angus",
    ActorCreationKey = "TB_Angus",
    ActorType = "TB_Angus"
  },
  {
    ActorTag = "TB_HeadlessHorse",
    ActorCreationKey = "TB_HeadlessHorse",
    ActorType = "TB_HeadlessHorse"
  },
  {
    ActorTag = "TB_Philippe",
    ActorCreationKey = "TB_Philippe",
    ActorType = "TB_Philippe"
  },
  {
    ActorTag = "TB_Tantor",
    ActorCreationKey = "TB_Tantor",
    ActorType = "TB_Tantor"
  },
  {
    ActorTag = "TS_BullsEye",
    ActorCreationKey = "AV_Bullseye",
    ActorType = "AV_Bullseye"
  },
  {
    ActorTag = "MU_Archie",
    ActorCreationKey = "MU_Archie",
    ActorType = "MU_Archie"
  },
  {
    IsUsableByCarvatar = true,
    ActorCreationKey = "RR_Slingshot",
    ActorType = "Cannon"
  },
  {
    ActorTag = "Player_RR_Stunt_Car",
    ActorCreationKey = "RR_Stunt_Car",
    ActorType = "RR_Stunt_Car"
  },
  {
    ActorTag = "Player_RR_Stunt_Car",
    ActorCreationKey = "RR_Stunt_Car_Monster",
    ActorType = "RR_Stunt_Car"
  },
  {
    ActorTag = "Player_RR_Stunt_Car",
    ActorCreationKey = "RR_Stunt_Car_Mini",
    ActorType = "RR_Stunt_Car"
  },
  {
    ActorCreationKey = "TB_AutopiaCar",
    ActorType = "TB_AutopiaCar"
  },
  {
    ActorCreationKey = "TB_AutopiaCar_Monster",
    ActorType = "TB_AutopiaCar"
  },
  {
    ActorCreationKey = "TB_AutopiaCar_Mini",
    ActorType = "TB_AutopiaCar"
  },
  {
    ActorCreationKey = "TB_DisneylandTram",
    ActorType = "TB_DisneylandTram"
  },
  {
    ActorCreationKey = "TB_DisneylandTram_Monster",
    ActorType = "TB_DisneylandTram"
  },
  {
    ActorCreationKey = "TB_DisneylandTram_Mini",
    ActorType = "TB_DisneylandTram"
  },
  {
    ActorTag = "SR_Cart_Vanellope",
    ActorCreationKey = "SR_Cart_Vanellope",
    ActorType = "SR_Cart_Vanellope"
  },
  {
    ActorTag = "SR_Cart_Vanellope",
    ActorCreationKey = "SR_Cart_Vanellope",
    ActorType = "SR_Cart_Vanellope"
  },
  {
    ActorTag = "SR_Cart_Vanellope",
    ActorCreationKey = "SR_Cart_Vanellope_Monster",
    ActorType = "SR_Cart_Vanellope"
  },
  {
    ActorTag = "SR_Cart_Vanellope",
    ActorCreationKey = "SR_Cart_Vanellope_Mini",
    ActorType = "SR_Cart_Vanellope"
  },
  {
    ActorTag = "SR_Cart_King",
    ActorCreationKey = "SR_Cart_King",
    ActorType = "SR_Cart_King"
  },
  {
    ActorTag = "SR_Cart_King",
    ActorCreationKey = "SR_Cart_King_Mini",
    ActorType = "SR_Cart_King"
  },
  {
    ActorTag = "SR_Cart_King",
    ActorCreationKey = "SR_Cart_King_Monster",
    ActorType = "SR_Cart_King"
  },
  {
    ActorTag = "WR_RALPH_CAR",
    ActorCreationKey = "wr_ralph_car",
    ActorType = "WR_RALPH_CAR"
  },
  {
    ActorTag = "WR_RALPH_CAR",
    ActorCreationKey = "wr_ralph_car_Monster",
    ActorType = "WR_RALPH_CAR"
  },
  {
    ActorTag = "WR_RALPH_CAR",
    ActorCreationKey = "wr_ralph_car_Mini",
    ActorType = "WR_RALPH_CAR"
  },
  {
    ActorTag = "INC_MrInc_SportsCar",
    ActorCreationKey = "TB_MrInc_SportsCar",
    ActorType = "INC_MrInc_SportsCar"
  },
  {
    ActorTag = "INC_MrInc_SportsCar",
    ActorCreationKey = "TB_MrInc_SportsCar_Monster",
    ActorType = "INC_MrInc_SportsCar"
  },
  {
    ActorTag = "INC_MrInc_SportsCar",
    ActorCreationKey = "TB_MrInc_SportsCar_Mini",
    ActorType = "INC_MrInc_SportsCar"
  },
  {
    ActorTag = "TB_MickeysJalopy",
    ActorCreationKey = "TB_MickeysJalopy",
    ActorType = "TB_MickeysJalopy"
  },
  {
    ActorTag = "TB_MickeysJalopy",
    ActorCreationKey = "TB_MickeysJalopy_Monster",
    ActorType = "TB_MickeysJalopy"
  },
  {
    ActorTag = "TB_MickeysJalopy",
    ActorCreationKey = "TB_MickeysJalopy_Mini",
    ActorType = "TB_MickeysJalopy"
  },
  {
    ActorTag = "TB_Lightrunner",
    ActorCreationKey = "TB_Lightrunner",
    ActorType = "TB_Lightrunner"
  },
  {
    ActorTag = "TB_Lightrunner",
    ActorCreationKey = "TB_Lightrunner_Monster",
    ActorType = "TB_Lightrunner"
  },
  {
    ActorTag = "TB_Lightrunner",
    ActorCreationKey = "TB_Lightrunner_Mini",
    ActorType = "TB_Lightrunner"
  },
  {
    ActorTag = "TB_CinderellaCoach",
    ActorCreationKey = "TB_CinderellaCoach",
    ActorType = "TB_CinderellaCoach"
  },
  {
    ActorTag = "TB_CinderellaCoach",
    ActorCreationKey = "TB_CinderellaCoach_Monster",
    ActorType = "TB_CinderellaCoach"
  },
  {
    ActorTag = "TB_CinderellaCoach",
    ActorCreationKey = "TB_CinderellaCoach_Mini",
    ActorType = "TB_CinderellaCoach"
  },
  {
    ActorCreationKey = "TB_CruellaCar",
    ActorType = "TB_CruellaCar"
  },
  {
    ActorCreationKey = "TB_CruellaCar_Monster",
    ActorType = "TB_CruellaCar"
  },
  {
    ActorCreationKey = "TB_CruellaCar_Mini",
    ActorType = "TB_CruellaCar"
  },
  {
    ActorCreationKey = "TB_ElectricMayhemBus",
    ActorType = "TB_ElectricMayhemBus"
  },
  {
    ActorCreationKey = "TB_ElectricMayhemBus_Monster",
    ActorType = "TB_ElectricMayhemBus"
  },
  {
    ActorCreationKey = "TB_ElectricMayhemBus_Mini",
    ActorType = "TB_ElectricMayhemBus"
  },
  {
    ActorCreationKey = "TB_LR_Jupiter",
    ActorType = "TB_Jupiter_Train"
  },
  {
    ActorCreationKey = "TB_LR_Jupiter_Monster",
    ActorType = "TB_Jupiter_Train"
  },
  {
    ActorCreationKey = "TB_LR_Jupiter_Mini",
    ActorType = "TB_Jupiter_Train"
  },
  {ActorCreationKey = "TB_MikeCar", ActorType = "TB_MikeCar"},
  {
    ActorCreationKey = "TB_MikeCar_Monster",
    ActorType = "TB_MikeCar"
  },
  {
    ActorCreationKey = "TB_MikeCar_Mini",
    ActorType = "TB_MikeCar"
  },
  {
    ActorCreationKey = "TB_MRINC_CAR",
    ActorType = "IN_MRINC_CAR"
  },
  {
    ActorCreationKey = "TB_MRINC_CAR_Monster",
    ActorType = "IN_MRINC_CAR"
  },
  {
    ActorCreationKey = "TB_MRINC_CAR_Mini",
    ActorType = "IN_MRINC_CAR"
  },
  {
    ActorCreationKey = "TB_PizzaPlanetTruck",
    ActorType = "TB_PizzaPlanetTruck"
  },
  {
    ActorCreationKey = "TB_PizzaPlanetTruck_Monster",
    ActorType = "TB_PizzaPlanetTruck"
  },
  {
    ActorCreationKey = "TB_PizzaPlanetTruck_Mini",
    ActorType = "TB_PizzaPlanetTruck"
  },
  {
    ActorCreationKey = "TB_Stagecoach",
    ActorType = "TB_Stagecoach"
  },
  {
    ActorCreationKey = "TB_Stagecoach_Monster",
    ActorType = "TB_Stagecoach"
  },
  {
    ActorCreationKey = "TB_Stagecoach_Mini",
    ActorType = "TB_Stagecoach"
  },
  {
    ActorCreationKey = "TS_BuzzRide",
    ActorType = "TS_BuzzRide"
  },
  {
    ActorCreationKey = "TS_BuzzRide_Monster",
    ActorType = "TS_BuzzRide"
  },
  {
    ActorCreationKey = "TS_BuzzRide_Mini",
    ActorType = "TS_BuzzRide"
  },
  {
    ActorTag = "LR_Silver",
    ActorCreationKey = "LR_Silver",
    ActorType = "AV_Silver"
  }
}
L4_4 = "UseCarsWeaponLocks"
L3_3[L4_4] = true
L4_4 = "GooAllowedInPlayset"
L3_3[L4_4] = true
L4_4 = "ShowCarEnergyMeterUI"
L3_3[L4_4] = true
L4_4 = "PlayableAvatars"
L3_3[L4_4] = "AV_MrIncredible,AV_ElastiGirl,AV_Dash,AV_Violet,AV_Syndrome,AV_Frozone,PIR_JackSparrow,PIR_Barbossa,PIR_DavyJones,MU_Sully,MU_Mike,MU_Randall,LR_LoneRanger,LR_Tonto,AV_Buzz,AV_Jessie,AV_Woody,AV_Zurg,AV_McQueen,AV_Holly,AV_Mater,AV_Francesco,AV_Cars_Finn,AV_Cars_Luigi,AV_Cars_Ramone,AV_Cars_Flo,AV_Cars_ChickHicks,AV_Cars_King,AV_Cars_Carla,AV_Cars_Shu,AV_Fillmore,FRO_Anna,FRO_Elsa,NBC_JackSkellington,TB_MickeyMouse,PNF_Phineas,PNF_Perry,WR_Ralph,WR_Vanellope,TAN_Rapunzel"
L4_4 = "UIChildrenPlaysets"
L3_3[L4_4] = "Developer_Worlds"
L4_4 = true
L3_3.ParachuteAvailableOnLevel = L4_4
L4_4 = "LoadVehicleMeridianData"
L3_3[L4_4] = true
L4_4 = "LoadingScreen_ToyBox"
L3_3.LoadingScreen = L4_4
L4_4 = "ShowDamageNumbers"
L3_3[L4_4] = true
L2_2.RumpusRoom = L3_3
L3_3 = {}
L4_4 = "CustomizeCho1"
L3_3[L4_4] = "Cars_CharacterCustomizeA"
L4_4 = "PlaysetUniqueID"
L3_3[L4_4] = 2
L4_4 = "playsetDict"
L3_3[L4_4] = "CA"
L4_4 = "StartWorld"
L3_3[L4_4] = "CA_RadiatorSprings"
L4_4 = "avatarSuffix"
L3_3[L4_4] = "_PS"
L4_4 = "WorldIcon"
L3_3[L4_4] = "IN_LOGO_Cars"
L4_4 = "LVL_CARS"
L3_3.inventoryFilter = L4_4
L4_4 = "AgentBudgetGroups"
L3_3[L4_4] = {
  Transports = {
    MaxAgents = 12,
    DefaultUnloadPriority = "TransportUnloadPriority",
    SubBudgets = {
      {
        ActorTypeFilter = "CA_TowableRamp",
        IsMaxPerPlayer = false,
        MaxAgents = 4
      },
      {
        ActorTypeFilter = "CA_Wrecking_Ball",
        IsMaxPerPlayer = false,
        MaxAgents = 4
      },
      {
        ActorTypeFilter = "AgentBudget_Transport"
      },
      {
        UnloadPriority = "DriveableUnloadPriority",
        ActorTypeFilter = "AgentBudget_Transport_Vehicle"
      }
    }
  }
}
L4_4 = "MissionParams"
L3_3[L4_4] = {
  EncounterAudio_MaxMissionEncounterDelay = 15,
  ActivationLikelihood = 30,
  MissionRewardsFile = "CA_MissionRewards.lua",
  MissionCelebrationChoMedium = "Celeb_CAR_Large",
  MissionCelebrationChoLarge = "Celeb_CAR_Large",
  MissionCelebrationReactLarge = "celb",
  BeaconMap = {
    {
      "MissionAvailableDefault",
      "Beacon_Missions_Excl_Cars",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveDefault",
      "Beacon_Missions_Ques_Cars",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailableAlertDefault",
      "Beacon_Mission_Pow_Cars",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveAlertDefault",
      "Beacon_Mission_Pow_Cars",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailable_Activity",
      "Beacon_Missions_Excl_Cars",
      "Layout|PlacementA"
    },
    {
      "MissionActive_Activity",
      "Beacon_Missions_Ques_Cars",
      "Layout|PlacementA"
    },
    {
      "MissionAvailableAlert_Activity",
      "Beacon_Mission_Pow_Cars",
      "Layout|PlacementA"
    },
    {
      "MissionActiveAlert_Activity",
      "Beacon_Mission_Pow_Cars",
      "Layout|PlacementA"
    },
    {
      "MissionAvailable_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "FocusPointNone",
      "",
      "",
      0
    },
    {
      "FocusPointDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultShort",
      "Beacon_Mission_Arrow_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultArrowOnly",
      "Beacon_Mission_Arrow_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefault",
      "Beacon_Mission_ArrowRed",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultShort",
      "Beacon_Mission_ArrowRed_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultArrowOnly",
      "Beacon_Mission_ArrowRed_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointAlertDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "TS_BeaconGen",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "Beacon_Mission_Target",
      "Beacon_Mission_Target",
      "Layout|PlacementA",
      0
    }
  },
  EncounterAudio_MinWaitAfterPresentation = 10,
  MissionLogOrder = 2,
  EncounterAudio_MinMissionEncounterDelay = 10,
  EncounterAudio_SelectedWeightModifier = 3.5,
  SelectedWeightModifier = 3.5,
  UnselectedWeightModifier = 1.5,
  MinAlertDelayHigh = 20,
  MissionCompleteAudioStringer = "",
  MissionCelebrationChoSmall = "Celeb_CAR_Small",
  MissionTalkDelay = 8,
  ActivationRange = 40,
  FindMGReqMissions = {
    "CA_RadiatorSprings_Main_Mission_Log"
  },
  MissionAcceptedVO = "Avatar_Mission_Accept",
  DeactivationRange = 60,
  EncounterAudio_UnselectedWeightModifier = 1.5,
  MissionCelebrationReactSmall = "",
  ControlledMissionDelay = 1,
  EncounterAudio_MinWeight = 1,
  EncounterAudio_StartWeight = 10,
  StarsAvailable = 100,
  EncounterAudio_ActivationRange = 15,
  EncounterAudio_MissionEncounterDelayArmed = 5,
  MissionCelebrationReactMedium = "celb",
  MissionCompleteDelay = 0.1,
  DefaultRewardType = "INV_CARS_CASH",
  MinAlertDelayLow = 10,
  MaxActiveMissions = 2
}
L4_4 = "enteredLockName"
L3_3[L4_4] = "ACH_CARS_ENTERED"
L4_4 = "blockheadCustomizationFilter"
L3_3[L4_4] = "Cars"
L4_4 = "LoadingScreen_ToyBox"
L3_3.LoadingScreen = L4_4
L4_4 = "Type"
L3_3[L4_4] = "Playset"
L4_4 = "ResourceFiberBurstTime"
L3_3[L4_4] = 15
L4_4 = "ComboPointsMeter"
L3_3[L4_4] = "ComboCacheMeter"
L4_4 = "completedLockName"
L3_3[L4_4] = "ACH_CARS_COMPLETED"
L4_4 = "starName"
L3_3[L4_4] = "CARS_STAR"
L4_4 = "TransportManager"
L3_3[L4_4] = {
  {
    ActorCreationKey = "",
    ActorType = "Transport_NONE"
  },
  {
    Lock = "RC_TOY_TOWABLE_RAMP",
    ActorTag = "CA_TowableRamp",
    ActorCreationKey = "TowableRamp",
    ActorType = "CA_TowableRamp"
  },
  {
    Lock = "RC_TOY_BIG_BALL",
    ActorTag = "CA_Wrecking_Ball",
    ActorCreationKey = "CA_Wrecking_Ball",
    ActorType = "CA_Wrecking_Ball"
  }
}
L4_4 = "ActivityTypeDataFile"
L3_3[L4_4] = "ActivityTypeData_CA.lua"
L4_4 = "ShowDamageNumbers"
L3_3[L4_4] = false
L4_4 = "ShowCarEnergyMeterUI"
L3_3[L4_4] = true
L4_4 = "PlayableAvatars"
L3_3[L4_4] = "AV_MrIncredible,AV_ElastiGirl,AV_Dash,AV_Violet,AV_Syndrome,AV_Frozone,PIR_JackSparrow,PIR_Barbossa,PIR_DavyJones,MU_Sully,MU_Mike,MU_Randall,LR_LoneRanger,LR_Tonto,AV_Buzz,AV_Jessie,AV_Woody,AV_Zurg,AV_McQueen,AV_Holly,AV_Mater,AV_Francesco,AV_Cars_Finn,AV_Cars_Luigi,AV_Cars_Ramone,AV_Cars_Flo,AV_Cars_ChickHicks,AV_Cars_King,AV_Cars_Carla,AV_Cars_Shu,AV_Fillmore,FRO_Anna,FRO_Elsa,NBC_JackSkellington,TB_MickeyMouse,PNF_Phineas,PNF_Perry,WR_Ralph,WR_Vanellope,TAN_Rapunzel"
L4_4 = "CustomizeCho2"
L3_3[L4_4] = "Cars_CharacterCustomizeB"
L4_4 = "UseCarsWeaponLocks"
L3_3[L4_4] = true
L4_4 = "LoadVehicleMeridianData"
L3_3[L4_4] = true
L4_4 = "UseCarsTurboLocks"
L3_3[L4_4] = true
L4_4 = true
L3_3.splitScreenHorizontal = L4_4
L2_2.Cars = L3_3
L3_3 = {}
L4_4 = "CustomizeCho1"
L3_3[L4_4] = "PIR_CharacterCustomizeA"
L4_4 = "PlaysetUniqueID"
L3_3[L4_4] = 6
L4_4 = "playsetDict"
L3_3[L4_4] = "PI"
L4_4 = "StartWorld"
L3_3[L4_4] = "PC_BuccaneerBay"
L4_4 = "avatarSuffix"
L3_3[L4_4] = "_PS"
L4_4 = "WorldIcon"
L3_3[L4_4] = "IN_LOGO_Pirates"
L4_4 = "LoadingScreen_PIR"
L3_3.LoadingScreen = L4_4
L4_4 = "AgentBudgetGroups"
L3_3[L4_4] = {
  Transports = {
    MaxAgents = 4,
    DefaultUnloadPriority = "TransportUnloadPriority",
    SubBudgets = {
      {
        ActorTypeFilter = "PIR_Rowboat",
        IsMaxPerPlayer = true,
        MaxAgents = 1
      }
    }
  }
}
L4_4 = "enteredLockName"
L3_3[L4_4] = "ACH_PIRATES_ENTERED"
L4_4 = "Type"
L3_3[L4_4] = "Playset"
L4_4 = "ActivityBeaconsFile"
L3_3[L4_4] = "PiratesActivityBeacons.lua"
L4_4 = "ShowDamageNumbers"
L3_3[L4_4] = true
L4_4 = "MissionParams"
L3_3[L4_4] = {
  EncounterAudio_MaxMissionEncounterDelay = 120,
  ActivationLikelihood = 100,
  MissionRewardsFile = "PC_MissionRewards.lua",
  MissionCelebrationChoMedium = "Celeb_Pir_Large",
  MissionCelebrationChoLarge = "Celeb_Pir_Large",
  MissionCelebrationReactLarge = "celb",
  BeaconMap = {
    {
      "MissionAvailableDefault",
      "Beacon_Missions_Excl",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveDefault",
      "Beacon_Missions_Ques",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailableAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailable_Activity",
      "Beacon_Missions_Excl",
      "Layout|PlacementA"
    },
    {
      "MissionActive_Activity",
      "Beacon_Missions_Ques",
      "Layout|PlacementA"
    },
    {
      "MissionAvailableAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionActiveAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionAvailable_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "FocusPointNone",
      "",
      "",
      0
    },
    {
      "FocusPointDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultShort",
      "Beacon_Mission_Arrow_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultArrowOnly",
      "Beacon_Mission_Arrow_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefault",
      "Beacon_Mission_ArrowRed",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultShort",
      "Beacon_Mission_ArrowRed_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultArrowOnly",
      "Beacon_Mission_ArrowRed_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointAlertDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "TS_BeaconGen",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "Beacon_Mission_Target",
      "Beacon_Mission_Target",
      "Layout|PlacementA",
      0
    }
  },
  EncounterAudio_MinWaitAfterPresentation = 15,
  MissionLogOrder = 5,
  EncounterAudio_MinMissionEncounterDelay = 30,
  EncounterAudio_SelectedWeightModifier = 3.5,
  SelectedWeightModifier = 3.5,
  UnselectedWeightModifier = 1.5,
  MinAlertDelayHigh = 20,
  MissionCompleteAudioStringer = "",
  MissionCelebrationChoSmall = "Celeb_Pir_Small",
  MissionTalkDelay = 8,
  ActivationRange = 40,
  MissionAcceptedVO = "Avatar_Mission_Accept",
  DeactivationRange = 60,
  EncounterAudio_UnselectedWeightModifier = 1.5,
  MissionCelebrationReactSmall = "",
  ControlledMissionDelay = 1,
  EncounterAudio_MinWeight = 1,
  EncounterAudio_StartWeight = 10,
  StarsAvailable = 100,
  EncounterAudio_ActivationRange = 15,
  EncounterAudio_MissionEncounterDelayArmed = 5,
  MissionCelebrationReactMedium = "celb",
  MissionCompleteDelay = 1,
  DefaultRewardType = "INV_PIRATES_CURRENCY",
  MinAlertDelayLow = 10,
  MaxActiveMissions = 20
}
L4_4 = "starName"
L3_3[L4_4] = "PIRATES_STAR"
L4_4 = "TransportManager"
L3_3[L4_4] = {
  {
    ActorCreationKey = "",
    ActorType = "Transport_NONE"
  },
  {
    ActorCreationKey = "PIR_Rowboat",
    ActorType = "PIR_Rowboat"
  }
}
L4_4 = "vertexbufferHeapSizePS3"
L3_3[L4_4] = 35651584
L4_4 = "vertexbufferHeapSize360"
L3_3[L4_4] = 30408704
L4_4 = "ResourceFiberBurstTime"
L3_3[L4_4] = 15
L4_4 = "PlayableAvatars"
L3_3[L4_4] = "AV_MrIncredible,AV_ElastiGirl,AV_Dash,AV_Violet,AV_Syndrome,AV_Frozone,PIR_JackSparrow,PIR_Barbossa,PIR_DavyJones,MU_Sully,MU_Mike,MU_Randall,LR_LoneRanger,LR_Tonto,AV_Buzz,AV_Jessie,AV_Woody,AV_Zurg,AV_McQueen,AV_Holly,AV_Mater,AV_Francesco,AV_Cars_Finn,AV_Cars_Luigi,AV_Cars_Ramone,AV_Cars_Flo,AV_Cars_ChickHicks,AV_Cars_King,AV_Cars_Carla,AV_Cars_Shu,AV_Fillmore,FRO_Anna,FRO_Elsa,NBC_JackSkellington,TB_MickeyMouse,PNF_Phineas,PNF_Perry,WR_Ralph,WR_Vanellope,TAN_Rapunzel"
L4_4 = "completedLockName"
L3_3[L4_4] = "ACH_PIRATES_COMPLETED"
L4_4 = "ActivityTypeDataFile"
L3_3[L4_4] = "ActivityTypeData_PC.lua"
L3_3.inventoryFilter = "LVL_PIRATES"
L4_4 = "UseNonSplineTunneling"
L3_3[L4_4] = true
L4_4 = "ManageMaxNumHubsLoaded"
L3_3[L4_4] = true
L2_2.Pirates = L3_3
L3_3 = {}
L4_4 = "CustomizeCho1"
L3_3[L4_4] = "TS_CharacterCustomizeA"
L4_4 = "PlaysetUniqueID"
L3_3[L4_4] = 7
L4_4 = "playsetDict"
L3_3[L4_4] = "TS"
L4_4 = "StartWorld"
L3_3[L4_4] = "TS_MainTown"
L4_4 = "avatarSuffix"
L3_3[L4_4] = "_PS"
L4_4 = "WorldIcon"
L3_3[L4_4] = "IN_LOGO_ToyStoryInSpace"
L4_4 = "LVL_TOYSTORYINSPACE"
L3_3.inventoryFilter = L4_4
L4_4 = "AgentBudgetGroups"
L3_3[L4_4] = {
  Transports = {
    MaxAgents = 8,
    DefaultUnloadPriority = "TransportUnloadPriority",
    SubBudgets = {
      {
        ActorTypeFilter = "AV_Bullseye",
        IsMaxPerPlayer = true,
        MaxAgents = 1
      },
      {
        ActorTypeFilter = "TS_AlienHorse",
        IsMaxPerPlayer = true,
        MaxAgents = 1
      },
      {
        ActorTypeFilter = "AgentBudget_Transport"
      },
      {
        UnloadPriority = "DriveableUnloadPriority",
        ActorTypeFilter = "AgentBudget_Transport_Vehicle"
      }
    }
  }
}
L4_4 = "enteredLockName"
L3_3[L4_4] = "ACH_TSIS_ENTERED"
L4_4 = "blockheadCustomizationFilter"
L3_3[L4_4] = "ToyStory"
L4_4 = "Type"
L3_3[L4_4] = "Playset"
L4_4 = "vertexbufferHeapSize360"
L3_3[L4_4] = 19922944
L4_4 = "ShowDamageNumbers"
L3_3[L4_4] = false
L4_4 = "starName"
L3_3[L4_4] = "TSIS_STAR"
L4_4 = "TransportManager"
L3_3[L4_4] = {
  {
    ActorCreationKey = "",
    ActorType = "Transport_NONE"
  },
  {
    Lock = "RC_ROBO_BULLSEYE",
    ActorTag = "TS_AlienHorse",
    ActorCreationKey = "AlienHorse",
    ActorType = "TS_AlienHorse"
  },
  {
    Lock = "RC_BULLSEYE",
    ActorTag = "TS_BullsEye",
    ActorCreationKey = "AV_Bullseye",
    ActorType = "AV_Bullseye"
  }
}
L4_4 = "MissionParams"
L3_3[L4_4] = {
  EncounterAudio_MaxMissionEncounterDelay = 70,
  ActivationLikelihood = 30,
  MissionRewardsFile = "TS_MissionRewards.lua",
  MissionCelebrationChoMedium = "Celeb_TS_Large",
  MissionCelebrationChoLarge = "Celeb_TS_Large",
  MissionCelebrationReactLarge = "celb",
  BeaconMap = {
    {
      "MissionAvailableDefault",
      "Beacon_Missions_Excl",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveDefault",
      "Beacon_Missions_Ques",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailableAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailable_Activity",
      "Beacon_Missions_Excl",
      "Layout|PlacementA"
    },
    {
      "MissionActive_Activity",
      "Beacon_Missions_Ques",
      "Layout|PlacementA"
    },
    {
      "MissionAvailableAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionActiveAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionAvailable_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "FocusPointNone",
      "",
      "",
      0
    },
    {
      "FocusPointDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultShort",
      "Beacon_Mission_Arrow_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultArrowOnly",
      "Beacon_Mission_Arrow_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefault",
      "Beacon_Mission_ArrowRed",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultShort",
      "Beacon_Mission_ArrowRed_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultArrowOnly",
      "Beacon_Mission_ArrowRed_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointAlertDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "TS_BeaconGen",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "Beacon_Mission_Target",
      "Beacon_Mission_Target",
      "Layout|PlacementA",
      0
    }
  },
  EncounterAudio_MinWaitAfterPresentation = 15,
  MissionLogOrder = 1,
  EncounterAudio_MinMissionEncounterDelay = 25,
  EncounterAudio_SelectedWeightModifier = 3.5,
  SelectedWeightModifier = 3.5,
  UnselectedWeightModifier = 1.5,
  MinAlertDelayHigh = 20,
  MissionCompleteAudioStringer = "",
  MissionCelebrationChoSmall = "Celeb_TS_Small",
  MissionTalkDelay = 8,
  ActivationRange = 40,
  FindMGReqMissions = {
    "TS_MainTown_Story_BuildALot"
  },
  MissionAcceptedVO = "Avatar_Mission_Accept",
  DeactivationRange = 60,
  EncounterAudio_UnselectedWeightModifier = 1.5,
  MissionCelebrationReactSmall = "",
  ControlledMissionDelay = 30,
  EncounterAudio_MinWeight = 1,
  EncounterAudio_StartWeight = 10,
  StarsAvailable = 100,
  EncounterAudio_ActivationRange = 15,
  EncounterAudio_MissionEncounterDelayArmed = 5,
  MissionCelebrationReactMedium = "celb",
  MissionCompleteDelay = 1,
  DefaultRewardType = "INV_SPACE_CRYSTAL",
  MinAlertDelayLow = 10,
  MaxActiveMissions = 6
}
L4_4 = "PlayableAvatars"
L3_3[L4_4] = "AV_MrIncredible,AV_ElastiGirl,AV_Dash,AV_Violet,AV_Syndrome,AV_Frozone,PIR_JackSparrow,PIR_Barbossa,PIR_DavyJones,MU_Sully,MU_Mike,MU_Randall,LR_LoneRanger,LR_Tonto,AV_Buzz,AV_Jessie,AV_Woody,AV_Zurg,AV_McQueen,AV_Holly,AV_Mater,AV_Francesco,AV_Cars_Finn,AV_Cars_Luigi,AV_Cars_Ramone,AV_Cars_Flo,AV_Cars_ChickHicks,AV_Cars_King,AV_Cars_Carla,AV_Cars_Shu,AV_Fillmore,FRO_Anna,FRO_Elsa,NBC_JackSkellington,TB_MickeyMouse,PNF_Phineas,PNF_Perry,WR_Ralph,WR_Vanellope,TAN_Rapunzel"
L4_4 = "vertexbufferHeapSizePS3"
L3_3[L4_4] = 23068672
L4_4 = "completedLockName"
L3_3[L4_4] = "ACH_TSIS_COMPLETED"
L4_4 = "ActivityTypeDataFile"
L3_3[L4_4] = "ActivityTypeData_TS.lua"
L4_4 = "GooAllowedInPlayset"
L3_3[L4_4] = true
L4_4 = "LoadingScreen_ToyBox"
L3_3.LoadingScreen = L4_4
L2_2.ToyStoryInSpace = L3_3
L3_3 = {}
L4_4 = "CustomizeCho1"
L3_3[L4_4] = "INC_CharacterCustomizeA"
L4_4 = "PlaysetUniqueID"
L3_3[L4_4] = 3
L4_4 = "playsetDict"
L3_3[L4_4] = "IN"
L4_4 = "StartWorld"
L3_3[L4_4] = "IN_City"
L4_4 = "avatarSuffix"
L3_3[L4_4] = "_PS"
L4_4 = "WorldIcon"
L3_3[L4_4] = "IN_LOGO_Incredibles"
L4_4 = "LVL_INCREDIBLES"
L3_3.inventoryFilter = L4_4
L4_4 = "AgentBudgetGroups"
L3_3[L4_4] = {
  Transports = {
    MaxAgents = 4,
    DefaultUnloadPriority = "TransportUnloadPriority",
    SubBudgets = {
      {
        ActorTypeFilter = "INC_MrInc_SportsCar",
        IsMaxPerPlayer = true,
        MaxAgents = 1
      },
      {
        ActorTypeFilter = "IN_MRINC_CAR",
        IsMaxPerPlayer = true,
        MaxAgents = 1
      },
      {
        ActorTypeFilter = "TB_Helicopter_Bomb",
        IsMaxPerPlayer = true,
        MaxAgents = 1
      },
      {
        ActorTypeFilter = "AgentBudget_Transport"
      },
      {
        UnloadPriority = "DriveableUnloadPriority",
        ActorTypeFilter = "AgentBudget_Transport_Vehicle"
      }
    }
  }
}
L4_4 = "enteredLockName"
L3_3[L4_4] = "ACH_INCREDIBLES_ENTERED"
L4_4 = "blockheadCustomizationFilter"
L3_3[L4_4] = "Incredibles"
L4_4 = "Type"
L3_3[L4_4] = "Playset"
L4_4 = "ComboPointsMeter"
L3_3[L4_4] = "MeleeMeter"
L4_4 = "MissionParams"
L3_3[L4_4] = {
  EncounterAudio_MaxMissionEncounterDelay = 120,
  ActivationLikelihood = 30,
  MissionRewardsFile = "IN_MissionRewards.lua",
  MissionCelebrationChoMedium = "Celeb_Inc_Large",
  MissionCelebrationChoLarge = "Celeb_Inc_Large",
  MissionCelebrationReactLarge = "celb",
  BeaconMap = {
    {
      "MissionAvailableDefault",
      "Beacon_Missions_Excl",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveDefault",
      "Beacon_Missions_Ques",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailableAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailable_Activity",
      "Beacon_Missions_Excl",
      "Layout|PlacementA"
    },
    {
      "MissionActive_Activity",
      "Beacon_Missions_Ques",
      "Layout|PlacementA"
    },
    {
      "MissionAvailableAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionActiveAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionAvailable_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "FocusPointNone",
      "",
      "",
      0
    },
    {
      "FocusPointDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultShort",
      "Beacon_Mission_Arrow_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultArrowOnly",
      "Beacon_Mission_Arrow_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefault",
      "Beacon_Mission_ArrowRed",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultShort",
      "Beacon_Mission_ArrowRed_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultArrowOnly",
      "Beacon_Mission_ArrowRed_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointAlertDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "TS_BeaconGen",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "Beacon_Mission_Target",
      "Beacon_Mission_Target",
      "Layout|PlacementA",
      0
    }
  },
  EncounterAudio_MinWaitAfterPresentation = 15,
  MissionLogOrder = 3,
  EncounterAudio_MinMissionEncounterDelay = 30,
  EncounterAudio_SelectedWeightModifier = 3.5,
  SelectedWeightModifier = 3.5,
  UnselectedWeightModifier = 1.5,
  MinAlertDelayHigh = 20,
  MissionCompleteAudioStringer = "",
  MissionCelebrationChoSmall = "Celeb_Inc_Small",
  MissionTalkDelay = 8,
  ActivationRange = 40,
  FindMGReqMissions = {
    "Mission_Tutorial"
  },
  MissionAcceptedVO = "Avatar_Mission_Accept",
  DeactivationRange = 60,
  EncounterAudio_UnselectedWeightModifier = 1.5,
  MissionCelebrationReactSmall = "",
  ControlledMissionDelay = 1,
  EncounterAudio_MinWeight = 1,
  EncounterAudio_StartWeight = 10,
  StarsAvailable = 100,
  EncounterAudio_ActivationRange = 15,
  EncounterAudio_MissionEncounterDelayArmed = 5,
  MissionCelebrationReactMedium = "celb",
  MissionCompleteDelay = 0.1,
  DefaultRewardType = "INV_NSA_BUCKS",
  MinAlertDelayLow = 10,
  MaxActiveMissions = 10
}
L4_4 = "starName"
L3_3[L4_4] = "INCREDIBLES_STAR"
L4_4 = "TransportManager"
L3_3[L4_4] = {
  {
    ActorCreationKey = "",
    ActorType = "Transport_NONE"
  },
  {
    Lock = "RC_IN_MRINC_CAR",
    ActorTag = "IN_SuperCar",
    ActorCreationKey = "IN_MRINC_CAR",
    ActorType = "IN_MRINC_CAR"
  },
  {
    Lock = "RC_TOY_SUPER_HERO_HELICOPTER",
    ActorTag = "Vehicle_HelicopterBomb",
    ActorCreationKey = "INC_Helicopter_Bomb",
    ActorType = "TB_Helicopter_Bomb"
  },
  {
    Lock = "RC_INC_MrInc_SportsCar",
    ActorTag = "IN_SportsCar",
    ActorCreationKey = "INC_MrInc_SportsCar",
    ActorType = "INC_MrInc_SportsCar"
  }
}
L4_4 = "DisableVehicleToolSelect"
L3_3[L4_4] = true
L4_4 = "completedLockName"
L3_3[L4_4] = "ACH_INCREDIBLES_COMPLETED"
L4_4 = "ShowCarEnergyMeterUI"
L3_3[L4_4] = true
L4_4 = "PlayableAvatars"
L3_3[L4_4] = "AV_MrIncredible,AV_ElastiGirl,AV_Dash,AV_Violet,AV_Syndrome,AV_Frozone,PIR_JackSparrow,PIR_Barbossa,PIR_DavyJones,MU_Sully,MU_Mike,MU_Randall,LR_LoneRanger,LR_Tonto,AV_Buzz,AV_Jessie,AV_Woody,AV_Zurg,AV_McQueen,AV_Holly,AV_Mater,AV_Francesco,AV_Cars_Finn,AV_Cars_Luigi,AV_Cars_Ramone,AV_Cars_Flo,AV_Cars_ChickHicks,AV_Cars_King,AV_Cars_Carla,AV_Cars_Shu,AV_Fillmore,FRO_Anna,FRO_Elsa,NBC_JackSkellington,TB_MickeyMouse,PNF_Phineas,PNF_Perry,WR_Ralph,WR_Vanellope,TAN_Rapunzel"
L4_4 = "UseIncredibleVehicleWeapon"
L3_3[L4_4] = true
L4_4 = "ActivityTypeDataFile"
L3_3[L4_4] = "ActivityTypeData_IN.lua"
L4_4 = "LoadVehicleMeridianData"
L3_3[L4_4] = true
L4_4 = "LoadingScreen_Inc"
L3_3.LoadingScreen = L4_4
L4_4 = "ShowDamageNumbers"
L3_3[L4_4] = true
L2_2.Incredibles = L3_3
L3_3 = "LoneRanger"
L4_4 = {}
L4_4.CustomizeCho1 = "LR_CharacterCustomizeA"
L4_4.PlaysetUniqueID = 4
L4_4.playsetDict = "LR"
L4_4.StartWorld = "LR_Colby"
L4_4.avatarSuffix = "_PS"
L4_4.WorldIcon = "IN_LOGO_LoneRanger"
L4_4.LoadingScreen = "LoadingScreen_ToyBox"
L4_4.AgentBudgetGroups = {
  Transports = {
    MaxAgents = 10,
    DefaultUnloadPriority = "TransportUnloadPriority",
    SubBudgets = {
      {
        ActorTypeFilter = "AV_Silver",
        IsMaxPerPlayer = true,
        MaxAgents = 1
      },
      {
        ActorTypeFilter = "LR_Scout",
        IsMaxPerPlayer = true,
        MaxAgents = 1
      },
      {MaxAgents = 4, ActorTypeFilter = "LR_Mule"},
      {
        ActorTypeFilter = "AgentBudget_Transport"
      },
      {
        UnloadPriority = "DriveableUnloadPriority",
        ActorTypeFilter = "AgentBudget_Transport_Vehicle"
      }
    }
  }
}
L4_4.CatalogExcludeList = "INV_LR_Train_Flatbed"
L4_4.enteredLockName = "ACH_LONERANGER_ENTERED"
L4_4.Type = "Playset"
L4_4.ShowDamageNumbers = false
L4_4.starName = "LONE_RANGER_STAR"
L4_4.TransportManager = {
  {
    ActorCreationKey = "",
    ActorType = "Transport_NONE"
  },
  {
    Lock = "RC_LR_Elephant",
    ActorTag = "LR_Elephant",
    ActorCreationKey = "LR_Elephant",
    ActorType = "LR_Elephant"
  },
  {
    ActorTag = "LR_Mule",
    ActorCreationKey = "LR_Mule",
    ActorType = "LR_Mule"
  },
  {
    Lock = "RC_LR_Scout",
    ActorTag = "LR_Scout",
    ActorCreationKey = "LR_Scout",
    ActorType = "LR_Scout"
  },
  {
    Lock = "RC_TOY_LR_Silver",
    ActorTag = "LR_Silver",
    ActorCreationKey = "LR_Silver",
    ActorType = "AV_Silver"
  },
  {
    ActorTag = "LR_WildHorse",
    ActorCreationKey = "LR_WildHorse_Black",
    ActorType = "LR_WildHorse"
  },
  {
    ActorTag = "LR_WildHorse",
    ActorCreationKey = "LR_WildHorse_Brown",
    ActorType = "LR_WildHorse"
  },
  {
    ActorTag = "LR_WildHorse",
    ActorCreationKey = "LR_WildHorse_DeepBrown",
    ActorType = "LR_WildHorse"
  },
  {
    ActorTag = "LR_WildHorse",
    ActorCreationKey = "LR_WildHorse_MilkCow",
    ActorType = "LR_WildHorse"
  },
  {
    ActorTag = "LR_WildHorse",
    ActorCreationKey = "LR_WildHorse_MilkCow2",
    ActorType = "LR_WildHorse"
  },
  {
    ActorTag = "LR_WildHorse",
    ActorCreationKey = "LR_WildHorse_Yellow",
    ActorType = "LR_WildHorse"
  },
  {
    Lock = "RC_LR_ThunderingStallion",
    ActorCreationKey = "LR_SpiritHorseMount",
    ActorType = "LR_SpiritHorse"
  }
}
L4_4.PlayableAvatars = "AV_MrIncredible,AV_ElastiGirl,AV_Dash,AV_Violet,AV_Syndrome,AV_Frozone,PIR_JackSparrow,PIR_Barbossa,PIR_DavyJones,MU_Sully,MU_Mike,MU_Randall,LR_LoneRanger,LR_Tonto,AV_Buzz,AV_Jessie,AV_Woody,AV_Zurg,AV_McQueen,AV_Holly,AV_Mater,AV_Francesco,AV_Cars_Finn,AV_Cars_Luigi,AV_Cars_Ramone,AV_Cars_Flo,AV_Cars_ChickHicks,AV_Cars_King,AV_Cars_Carla,AV_Cars_Shu,AV_Fillmore,FRO_Anna,FRO_Elsa,NBC_JackSkellington,TB_MickeyMouse,PNF_Phineas,PNF_Perry,WR_Ralph,WR_Vanellope,TAN_Rapunzel"
L4_4.MissionParams = {
  EncounterAudio_MaxMissionEncounterDelay = 120,
  ActivationLikelihood = 40,
  MissionRewardsFile = "LR_MissionRewards.lua",
  MissionCelebrationChoMedium = "Celeb_LR_Large",
  MissionCelebrationChoLarge = "Celeb_LR_Large",
  MissionCelebrationReactLarge = "celb",
  BeaconMap = {
    {
      "MissionAvailableDefault",
      "Beacon_Missions_Excl",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveDefault",
      "Beacon_Missions_Ques",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailableAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionActiveAlertDefault",
      "Beacon_Mission_Pow",
      "Layout|PlacementA",
      0
    },
    {
      "MissionAvailable_Activity",
      "Beacon_Missions_Excl",
      "Layout|PlacementA"
    },
    {
      "MissionActive_Activity",
      "Beacon_Missions_Ques",
      "Layout|PlacementA"
    },
    {
      "MissionAvailableAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionActiveAlert_Activity",
      "Beacon_Mission_Pow",
      "Layout|PlacementA"
    },
    {
      "MissionAvailable_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Easy",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Medium",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailable_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActive_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionAvailableAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "MissionActiveAlert_Activity_Hard",
      "Beacon_Beginner",
      "ANC_Beacon_Beginner_00"
    },
    {
      "FocusPointNone",
      "",
      "",
      0
    },
    {
      "FocusPointDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultShort",
      "Beacon_Mission_Arrow_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointDefaultArrowOnly",
      "Beacon_Mission_Arrow_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefault",
      "Beacon_Mission_ArrowRed",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultShort",
      "Beacon_Mission_ArrowRed_Small",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointEnemyDefaultArrowOnly",
      "Beacon_Mission_ArrowRed_Only",
      "Layout|PlacementA",
      0
    },
    {
      "FocusPointAlertDefault",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "TS_BeaconGen",
      "Beacon_Mission_Arrow",
      "Layout|PlacementA",
      0
    },
    {
      "Beacon_Mission_Target",
      "Beacon_Mission_Target",
      "Layout|PlacementA",
      0
    }
  },
  EncounterAudio_MinWaitAfterPresentation = 15,
  MissionLogOrder = 5,
  EncounterAudio_MinMissionEncounterDelay = 30,
  EncounterAudio_SelectedWeightModifier = 3.5,
  SelectedWeightModifier = 3.5,
  UnselectedWeightModifier = 1.5,
  MinAlertDelayHigh = 20,
  MissionCompleteAudioStringer = "",
  MissionCelebrationChoSmall = "Celeb_LR_Small",
  MissionTalkDelay = 3,
  ActivationRange = 40,
  FindMGReqMissions = {
    "LR_Colby_Story_MissionLogTutorial"
  },
  MissionAcceptedVO = "Avatar_Mission_Accept",
  DeactivationRange = 60,
  EncounterAudio_UnselectedWeightModifier = 1.5,
  MissionCelebrationReactSmall = "",
  ControlledMissionDelay = 60,
  EncounterAudio_MinWeight = 1,
  EncounterAudio_StartWeight = 10,
  StarsAvailable = 100,
  EncounterAudio_ActivationRange = 15,
  EncounterAudio_MissionEncounterDelayArmed = 5,
  MissionCelebrationReactMedium = "celb",
  MissionCompleteDelay = 1,
  DefaultRewardType = "INV_LONERANGER_CURRENCY",
  MinAlertDelayLow = 10,
  MaxActiveMissions = 1
}
L4_4.completedLockName = "ACH_LONERANGER_COMPLETED"
L4_4.EowLevelSpecificDist = 15
L4_4.ActivityTypeDataFile = "ActivityTypeData_LR.lua"
L2_2[L3_3] = L4_4
L3_3 = "Miscellaneous"
L4_4 = {}
L4_4.PlaysetUniqueID = 1
L4_4.PlayableAvatars = "AV_MrIncredible,AV_ElastiGirl,AV_Dash,AV_Violet,AV_Syndrome,AV_Frozone,PIR_JackSparrow,PIR_Barbossa,PIR_DavyJones,MU_Sully,MU_Mike,MU_Randall,LR_LoneRanger,LR_Tonto,AV_Buzz,AV_Jessie,AV_Woody,AV_Zurg,AV_McQueen,AV_Holly,AV_Mater,AV_Francesco,AV_Cars_Finn,AV_Cars_Luigi,AV_Cars_Ramone,AV_Cars_Flo,AV_Cars_ChickHicks,AV_Cars_King,AV_Cars_Carla,AV_Cars_Shu,AV_Fillmore,FRO_Anna,FRO_Elsa,NBC_JackSkellington,TB_MickeyMouse,PNF_Phineas,PNF_Perry,WR_Ralph,WR_Vanellope,TAN_Rapunzel"
L4_4.ShowDamageNumbers = false
L4_4.Type = "Other"
L4_4.WorldIcon = "IN_LOGO_ToyBox"
L4_4.LoadingScreen = "LoadingScreen_ToyBox"
L2_2[L3_3] = L4_4
L1_1.PlaysetProperties = L2_2
L0_0.Records = L1_1
L1_1 = "Type"
L0_0[L1_1] = "Zones"
L1_1 = "Version"
L2_2 = 0.1
L0_0[L1_1] = L2_2
L1_1 = "ID"
L2_2 = 4
L0_0[L1_1] = L2_2
L1_1 = "DBName"
L0_0[L1_1] = "Zones"
ZoneList = L0_0
