--***********************************************************************
--
-- Exported using GameCommonStatData.lua: THIS IS A GENERATED FILE. DO NOT HAND EDIT IT.
--
--***********************************************************************

Data = Data or {}
Data.DBName='StatScopes'
Data.Version=0.0
Data.Records = {
	{ Package='Core',	 ScopeType=0,	 ScopeName='GLOBAL',	 UID=0,	 ParentScopeUID=-1},
	{ Package='Core',	 ScopeType=1,	 ScopeName='PLAYSET',	 UID=120,	 ParentScopeUID=0},
	{ Package='Core',	 ScopeType=2,	 ScopeName='PLAYER',	 UID=33,	 ParentScopeUID=120},
	{ Package='Core',	 ScopeType=2,	 ScopeName='Adventure',	 UID=122,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='GUEST',	 UID=131,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='GUEST2',	 UID=132,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Buzz',	 UID=42,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Woody',	 UID=43,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Jessie',	 UID=10,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_McQueen',	 UID=34,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Mater',	 UID=21,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Holly',	 UID=19,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Cars_Francesco',	 UID=108,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Mike',	 UID=24,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Sully',	 UID=4,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Randall',	 UID=91,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_JackSparrow',	 UID=25,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Barbossa',	 UID=118,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_DavyJones',	 UID=87,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_MrIncredible',	 UID=31,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_ElastiGirl',	 UID=9,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Dash',	 UID=35,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Violet',	 UID=44,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Syndrome',	 UID=50,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_LoneRanger',	 UID=86,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Tonto',	 UID=89,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_JackSkellington',	 UID=14,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Phineas',	 UID=119,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Perry',	 UID=117,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Rapunzel',	 UID=90,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_MickeyMouse',	 UID=112,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Anna',	 UID=116,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Elsa',	 UID=113,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Ralph',	 UID=115,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Vanellope',	 UID=114,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_MrIncredibleInfinite',	 UID=125,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_McQueenInfinite',	 UID=128,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_BuzzInfinite',	 UID=129,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_LoneRangerInfinite',	 UID=123,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_SullyInfinite',	 UID=126,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_JackSparrowInfinite',	 UID=127,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_PerryInfinite',	 UID=124,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_MickeyMouseInfinite',	 UID=130,	 ParentScopeUID=33},
	{ Package='Core',	 ScopeType=3,	 ScopeName='AV_Buzz_Glow',	 UID=133,	 ParentScopeUID=33},
}