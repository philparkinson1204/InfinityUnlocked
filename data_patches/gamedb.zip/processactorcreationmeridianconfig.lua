require 'lexers.csv'
require 'ex'
require 'filefind'
tup = require 'octane.tup'
require 'p4'
require 'lfs'

p4 = P4.P4()

p4:connect()
--print( 'p4.client = ' .. p4.client .. '\n' )

gameDir = arg[1]
gameDir = gameDir:gsub( '\\', '/' )
print( 'gameDir = '..gameDir )

subType = arg[2]
if subType == nil then
	print "No Subtype"
else
	print ("Subtype = " .. subType)
end

local buf = {};

buf[#buf + 1] = '#==============================================================================\n'
buf[#buf + 1] = '#\n'
buf[#buf + 1] = '#	Meridian_ActorCreationData.tup: AUTO-GENERATED. DO NOT HAND EDIT!\n'
buf[#buf + 1] = '#\n'
buf[#buf + 1] = '#==============================================================================\n\n\n'
buf[#buf + 1] = 'Items "ActorCreationDB" =\n'
buf[#buf + 1] = '{\n'

local allfiles = {}
for entry in filefind.glob(gameDir..'Content/Game/ActorList/Default/*.lua') do
	allfiles[#allfiles + 1] = entry.filename
end

local packageName = 'Core'


buf[#buf + 1] = '	Item "' .. packageName ..'" =\n'
buf[#buf + 1] = '	{\n'
buf[#buf + 1] = '		Selectable = 0\n'

local sortedNameTable = {}

-- loop through all files
for i=1,#allfiles do
	local curFile = allfiles[i]
--	print( curFile .. '\n' )

	-- load and process the file here.
	dofile( allfiles[i] )

	for type,v in pairs(Data.Actors) do
	
		for _,item in ipairs( v ) do
			if subType == nil then
				sortedNameTable[#sortedNameTable + 1] = item.Name
			else
				if item.SubType ~= nil and item.SubType == subType then
					sortedNameTable[#sortedNameTable + 1] = item.Name
				end
			end
		end
	end
	
	ActorList = nil
end

table.sort( sortedNameTable )
for k,v in ipairs(sortedNameTable) do
	if v ~= nil then
		buf[#buf + 1] = '		Item "' .. v .. '" = { On "Selected" = { SetNodeText = "' .. v .. '" } }\n'
	end
end



buf[#buf + 1] = '	}\n'
buf[#buf + 1] = '}\n'
buf = table.concat(buf)
local filename = gameDir..'content/game/meridian/Meridian_ActorCreationData'
if subType ~= nil then
	filename = filename .. '_' .. subType
end
filename = filename .. '.tup'

local fileBuffer = io.readall(filename)
if fileBuffer == buf then
	print( 'No change to file: '.. filename .. '\n' )
else
	-- the new data is different than the old data. checkout the file and write to it.
	p4:connect()
	p4.exception_level = 0
	if fileBuffer == nil then
		print( 'Writing file: '.. filename ..'...\n')
		io.writeall( filename, buf)
		print( 'Adding file: '.. filename ..'...\n')
		p4:run( "add", filename )
	else
		print( 'Checking out file: '.. filename ..'...\n')
		p4:run( "sync", '-f', filename )
		p4:run( "edit", filename )
		print( 'Writing file: '.. filename ..'...\n')
		io.writeall( filename, buf)
	end

	p4:disconnect()
end
